# UTS 41014 — Track A TurtleBot3 Waffle Pi

## Tutor instructions
1. Open `TrackA_WafflePi_RunAll.ipynb` in Google Colab.
2. Use **Runtime → Run all**. If the notebook is opened outside the repository, upload `TrackA_Tutor_Ready.zip` when prompted.
3. Review printed metrics, trajectory graph, 3D MP4 and `results/` files.

The notebook reuses the original supplied `tb3nav` modules and adapted XML. It uses a calibrated effective wheel model, geometric simulated LiDAR, and synthetic projected camera marker corners (not integrated rendered-image ArUco detection). Ground truth is only used for reporting and visualization. The 3D MP4 is a recorded-pose replay.

Dependencies are installed by the first notebook cell. CPU/GPU runtime and package versions can affect runtime and small numeric variations. The project has not been independently re-executed in a fresh Google Colab session.
