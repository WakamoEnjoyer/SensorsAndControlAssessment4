"""Recursive EKF (Assessment 3 structure): predict with odometry, then update with every marker that
was detected (NaN rows are skipped), one marker at a time. Returns (xh, P, nis_list)."""
import numpy as np
from scipy.stats import chi2
from .utils import wrap
from .models import f_uni, F_uni, Q_D, h_marker
from .vision import NoiseModel


class EKFConfig:
    def __init__(self, cfg, noise=None):
        self.cfg = cfg
        self.noise = noise or NoiseModel()
        self.T = cfg.T
        self.gate_p = 0.999


def ekf_step(xh, P, u, Z, ec, sigma_v=None, sigma_w=None):
    """xh (3,), P (3x3), u = odometry (v, w), Z = (M,3) marker measurements with NaN rows if not seen.
    nis entries are (nis, dof, accepted)."""
    cfg, T = ec.cfg, ec.T
    sv = cfg.ekf_sigma_v if sigma_v is None else sigma_v
    sw = cfg.ekf_sigma_w if sigma_w is None else sigma_w
    # ---- predict with the odometry actually measured ----
    F = F_uni(xh, u, T)
    Qd = Q_D(xh, u, T, sv, sw, cfg.q_floor)
    xh = f_uni(xh, u, T)
    P = F @ P @ F.T + Qd
    # ---- update, one marker at a time ----
    dims = 3 if cfg.meas_mode == "pose" else 2
    nis = []
    for i, zi in enumerate(Z):
        if not np.all(np.isfinite(zi[:dims])):
            continue                                           # marker not seen / dropped
        zhat, H = h_marker(xh, cfg.landmarks[i], cfg.meas_mode)   # Jacobian at the CURRENT estimate
        nu = zi[:dims] - zhat
        nu[1:] = wrap(nu[1:])
        R = ec.noise.R(zi[0], dims, cfg.r_scale)
        S = H @ P @ H.T + R
        d2 = float(nu @ np.linalg.solve(S, nu))
        ok = (not cfg.gate) or d2 < chi2.ppf(ec.gate_p, dims)
        nis.append((d2, dims, ok))
        if not ok:
            continue
        K = P @ H.T @ np.linalg.inv(S)
        xh = xh + K @ nu
        xh[2] = wrap(xh[2])
        IKH = np.eye(3) - K @ H
        P = IKH @ P @ IKH.T + K @ R @ K.T                      # Joseph form
        P = 0.5 * (P + P.T)                                    # symmetrise against round-off
    return xh, P, nis
