"""A* on an inflated occupancy grid (prior map) -> spline reference trajectory."""
import heapq
import numpy as np
from scipy.interpolate import CubicSpline


class Grid:
    def __init__(self, cfg):
        self.cfg = cfg
        xmin, xmax, ymin, ymax = cfg.room
        self.x0, self.y0, self.res = xmin, ymin, cfg.grid_res
        self.nx, self.ny = int((xmax - xmin) / self.res), int((ymax - ymin) / self.res)
        gx, gy = np.meshgrid(self.x0 + (np.arange(self.nx) + .5) * self.res,
                             self.y0 + (np.arange(self.ny) + .5) * self.res, indexing="ij")
        occ = np.zeros((self.nx, self.ny), bool)
        for cx, cy, r in cfg.obstacles:
            occ |= np.hypot(gx - cx, gy - cy) < r + cfg.inflate
        occ |= (gx < xmin + cfg.inflate) | (gx > xmax - cfg.inflate)
        occ |= (gy < ymin + cfg.inflate) | (gy > ymax - cfg.inflate)
        self.occ = occ

    def cell(self, p):
        return (int(np.clip((p[0] - self.x0) / self.res, 0, self.nx - 1)),
                int(np.clip((p[1] - self.y0) / self.res, 0, self.ny - 1)))

    def pos(self, c):
        return np.array([self.x0 + (c[0] + .5) * self.res, self.y0 + (c[1] + .5) * self.res])

    def free_line(self, p, q):
        n = int(np.linalg.norm(q - p) / (self.res / 2)) + 2
        return all(not self.occ[self.cell(p + t * (q - p))] for t in np.linspace(0, 1, n))

    def astar(self, start, goal):
        s, g = self.cell(start), self.cell(goal)
        occ = self.occ.copy()                       # the robot may start inside the safety margin
        occ[max(s[0] - 3, 0):s[0] + 4, max(s[1] - 3, 0):s[1] + 4] = False
        openq, came, cost = [(0, s)], {s: None}, {s: 0.0}
        while openq:
            _, cur = heapq.heappop(openq)
            if cur == g:
                break
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    if dx == dy == 0:
                        continue
                    n = (cur[0] + dx, cur[1] + dy)
                    if not (0 <= n[0] < self.nx and 0 <= n[1] < self.ny) or occ[n]:
                        continue
                    nc = cost[cur] + np.hypot(dx, dy)
                    if n not in cost or nc < cost[n]:
                        cost[n], came[n] = nc, cur
                        heapq.heappush(openq, (nc + np.hypot(n[0] - g[0], n[1] - g[1]), n))
        if g not in came:
            raise RuntimeError("A*: no path")
        path, c = [], g
        while c is not None:
            path.append(self.pos(c)); c = came[c]
        return path[::-1]


def build_reference(cfg, start_xy, start_theta):
    """A* on the inflated prior map -> spline -> dense Path (x, y, theta_path, kappa, arc length)."""
    grid = Grid(cfg)
    wp = grid.astar(np.array(start_xy), np.array(cfg.approach_pt))
    pts = [np.array(start_xy)]                      # line-of-sight shortcutting
    i = 0
    while i < len(wp) - 1:
        j = len(wp) - 1
        while j > i + 1 and not grid.free_line(wp[i], wp[j]):
            j -= 1
        pts.append(wp[j]); i = j
    pts.append(np.array(cfg.approach_pt)); pts.append(np.array(cfg.dock_pose[:2]))
    pts = np.array(pts)
    s = np.r_[0, np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))]
    cs = CubicSpline(s, pts, bc_type=((1, [np.cos(start_theta), np.sin(start_theta)]),
                                      (1, [np.cos(cfg.dock_pose[2]), np.sin(cfg.dock_pose[2])])))
    # dense samples along the spline, then (x, y, theta_path, kappa, arc length) as in Assessment 3
    sc = np.arange(0.0, s[-1] + 1e-9, 0.005)
    d1, d2 = cs(sc, 1), cs(sc, 2)
    X = cs(sc)
    sp = np.hypot(d1[:, 0], d1[:, 1])
    kappa = (d1[:, 0] * d2[:, 1] - d1[:, 1] * d2[:, 0]) / sp ** 3
    th = np.unwrap(np.arctan2(d1[:, 1], d1[:, 0]))
    arc = np.r_[0, np.cumsum(np.hypot(np.diff(X[:, 0]), np.diff(X[:, 1])))]
    clr = min(np.min(np.hypot(X[:, 0] - cx, X[:, 1] - cy) - r) for cx, cy, r in cfg.obstacles)
    from .control import Path
    return Path(X[:, 0], X[:, 1], th, kappa, arc), clr
