"""Lightweight 2D TurtleBot3 simulator (stand-in for MuJoCo, same interface).

Two independent random streams (robot = seed, sensors = seed + 1) so differences between runs
come from the design, not from luck (Assessment 3 convention).

The estimator and controller only ever receive `Measurements`. `ground_truth()` is for EVALUATION ONLY.
"""
from dataclasses import dataclass
import numpy as np
from .utils import wrap
from .frames import pose2SE3, T_B_C, T_W_M, marker_corners_M, make_camera


@dataclass
class Measurements:
    t: float
    odom: tuple          # (v, w) from wheel encoders
    corners: dict        # marker id -> 4x2 pixel corners (raw detections; ids not visible are absent)
    lidar: np.ndarray    # ranges at Sim2D.lidar_angles (robot frame); lidar_max means "no return"


class Sim2D:
    def __init__(self, cfg, x0, seed=0, noise_scale=1.0, wheel_error=None, slip=(1.0, 1.0),
                 kick_std=0.0, kick_rate=0.2, blackout=()):
        self.cfg = cfg
        self.rng_robot, self.rng_sensor = np.random.default_rng(seed), np.random.default_rng(seed + 1)
        self._x = np.array(x0, float)
        self.t, self.s = 0.0, noise_scale
        self.wheel_error = cfg.wheel_error if wheel_error is None else wheel_error
        self.slip, self.kick_std, self.kick_rate, self.blackout = slip, kick_std, kick_rate, blackout
        self.lidar_angles = np.linspace(-np.pi, np.pi, cfg.lidar_n, endpoint=False)
        self.collided, self.min_clearance = False, np.inf
        self.cam = make_camera(cfg)
        self._TBC = T_B_C(cfg)
        self._TWM = {i: T_W_M(cfg, i) for i in cfg.landmarks}
        self._obj = marker_corners_M(cfg)
        self._Pw = {i: (T * self._obj.T) for i, T in self._TWM.items()}      # 3x4 corners in W
        self.d_wheel = 0.0

    def ground_truth(self):
        """EVALUATION ONLY. Never pass this to the estimator or controller."""
        return self._x.copy()

    # ---------------- dynamics ----------------
    def step(self, u):
        c, T = self.cfg, self.cfg.T
        v_cmd = float(np.clip(u[0], -c.v_max, c.v_max))
        w_cmd = float(np.clip(u[1], -c.omega_max, c.omega_max))
        # worn wheel: constant yaw-rate bias that grows with speed (NOT seen by the encoders)
        self.d_wheel = v_cmd * self.wheel_error / c.wheel_sep
        v = v_cmd * self.slip[0] + self.rng_robot.normal(0, c.act_sigma_v)
        w = w_cmd * self.slip[1] + self.d_wheel + self.rng_robot.normal(0, c.act_sigma_w)
        if self.kick_std > 0 and self.rng_robot.random() < self.kick_rate * T:
            self._x[2] += self.rng_robot.normal(0, self.kick_std)
        th_m = self._x[2] + 0.5 * w * T
        self._x += np.array([v * T * np.cos(th_m), v * T * np.sin(th_m), w * T])
        self._x[2] = wrap(self._x[2])
        self.t += T
        self._collision()
        odom = (v_cmd + self.rng_sensor.normal(0, self.s * c.enc_sigma_v),
                w_cmd + self.rng_sensor.normal(0, self.s * c.enc_sigma_w))
        return Measurements(self.t, odom, self._camera(), self._lidar())

    # ---------------- camera: project marker corners through the pinhole model ----------------
    def _camera(self):
        c = self.cfg
        if any(t0 <= self.t < t1 for t0, t1 in self.blackout):
            return {}
        x, y, th = self._x
        T_W_C = pose2SE3(self._x) * self._TBC
        T_C_W = T_W_C.inv()
        W, H = c.image_size
        out = {}
        for i, (mx, my, nu) in c.landmarks.items():
            dx, dy = mx - x, my - y
            r = np.hypot(dx, dy)
            if r > c.cam_range:
                continue
            # marker must face the robot: angle between its normal and the line of sight
            if np.cos(nu) * (-dx) / r + np.sin(nu) * (-dy) / r < np.cos(c.cam_max_view_angle):
                continue
            Pc = T_C_W * self._Pw[i]
            if np.any(Pc[2] < 0.1) or self._occluded((x, y), (mx, my)):
                continue
            uv = self.cam.project_point(self._Pw[i], pose=T_W_C)            # 2x4 pixels
            if (uv[0].min() < c.px_margin or uv[0].max() > W - c.px_margin or
                    uv[1].min() < c.px_margin or uv[1].max() > H - c.px_margin):
                continue
            if self.rng_sensor.random() < c.p_drop:                          # random missed detection
                continue
            out[i] = uv.T + self.rng_sensor.normal(0, self.s * c.sigma_px, (4, 2))
        return out

    def _occluded(self, p, q):
        p, q = np.array(p), np.array(q)
        d = q - p
        for cx, cy, r in self.cfg.obstacles:
            t = np.clip(np.dot(np.array([cx, cy]) - p, d) / np.dot(d, d), 0, 1)
            if np.linalg.norm(p + t * d - [cx, cy]) < r:
                return True
        return False

    # ---------------- 2D LiDAR ----------------
    def _lidar(self):
        c = self.cfg
        x, y, th = self._x
        a = th + self.lidar_angles
        d = np.stack([np.cos(a), np.sin(a)], 1)
        xmin, xmax, ymin, ymax = c.room
        with np.errstate(divide="ignore", invalid="ignore"):
            tx = np.where(d[:, 0] > 1e-12, (xmax - x) / d[:, 0],
                          np.where(d[:, 0] < -1e-12, (xmin - x) / d[:, 0], np.inf))
            ty = np.where(d[:, 1] > 1e-12, (ymax - y) / d[:, 1],
                          np.where(d[:, 1] < -1e-12, (ymin - y) / d[:, 1], np.inf))
        t = np.minimum(tx, ty)
        for cx, cy, r in c.obstacles:
            fx, fy = x - cx, y - cy
            b = d[:, 0] * fx + d[:, 1] * fy
            disc = b * b - (fx * fx + fy * fy - r * r)
            t1 = -b - np.sqrt(np.where(disc >= 0, disc, 0))
            ok = (disc >= 0) & (t1 > 0) & (t1 < t)
            t = np.where(ok, t1, t)
        hit = t < c.lidar_max
        t = np.minimum(t, c.lidar_max)
        t = np.where(hit, t + self.rng_sensor.normal(0, c.lidar_sigma, t.shape), t)
        return t

    def _collision(self):
        c = self.cfg
        x, y, _ = self._x
        xmin, xmax, ymin, ymax = c.room
        cl = min(x - xmin, xmax - x, y - ymin, ymax - y) - c.robot_radius
        for cx, cy, r in c.obstacles:
            cl = min(cl, np.hypot(x - cx, y - cy) - r - c.robot_radius)
        self.min_clearance = min(self.min_clearance, cl)
        if cl < 0:
            self.collided = True
