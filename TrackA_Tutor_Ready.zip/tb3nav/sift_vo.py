"""Monocular SIFT visual odometry (Assessment 2, Part B), adapted to the robot's forward camera.

Convention (the A2 warning): CentralCamera.decomposeE returns the pose of camera 2 with respect to camera 1,
i.e. the CAMERA'S MOTION. Do not invert it again. Monocular scale is unobservable, so `scale` is supplied; here it
comes from the wheel speed (v * T), which is a real, ground-truth-free way to recover scale but fails under wheel slip.
"""
import numpy as np
import spatialmath.base as smb
from spatialmath import SE3
from machinevisiontoolbox import Image
from .icp_odometry import delta_to_odom


class SIFTOdometry:
    def __init__(self, camera, nfeatures=1500, ratio_thresh=0.75, max_rot_deg=10.0):
        self.camera, self.nfeatures, self.ratio, self.max_rot_deg = camera, nfeatures, ratio_thresh, max_rot_deg

    def _as_image(self, image):
        return image if isinstance(image, Image) else Image(np.asarray(image))

    def extract_features(self, image):
        """B.1: greyscale, then SIFT."""
        im = self._as_image(image)
        if im.iscolor:
            im = im.mono()
        return im.SIFT(nfeatures=self.nfeatures)

    def match_features(self, f1, f2):
        """B.2: Lowe's ratio test is applied inside the toolbox; `ratio` IS the threshold. None if degenerate."""
        if f1 is None or f2 is None or len(f1) < 8 or len(f2) < 8:
            return None
        m = f1.match(f2, ratio=self.ratio)
        return m if (m is not None and len(m) >= 8) else None

    def estimate_relative_pose(self, image1, image2, scale=1.0):
        """B.3: returns (SE3 camera motion with |t| = scale, num_inliers, info). Identity SE3 on failure."""
        info = {"num_matches": 0, "ok": False}
        m = self.match_features(self.extract_features(image1), self.extract_features(image2))
        if m is None:
            return SE3(), 0, info
        info["num_matches"] = len(m)
        out = self.camera.points2E(m.p1, m.p2, method="ransac", prob=0.999, threshold=1.0)
        if out is None:
            return SE3(), 0, info
        E, inliers = out if isinstance(out, tuple) else (out, np.ones(len(m), bool))
        if E is None or np.sum(inliers) < 8:
            return SE3(), 0, info
        T = self.camera.decomposeE(E, m)          # pass the MATCH object so cheirality can pick the right solution
        R = smb.trnorm(T.R)
        if np.degrees(np.arccos(np.clip((np.trace(R) - 1) / 2, -1, 1))) > self.max_rot_deg:
            return SE3(), int(np.sum(inliers)), info          # blunder gate: caller falls back to another source
        t = T.t / max(np.linalg.norm(T.t), 1e-12) * scale
        info["ok"] = True
        return SE3.Rt(R, t), int(np.sum(inliers)), info


def camera_motion_to_base(T_B_C, T_C):
    """Express a motion written in camera coordinates in the base frame: T_B = T_B_C * T_C * T_B_C^-1 (frame change)."""
    return SE3(smb.trnorm((T_B_C * T_C * T_B_C.inv()).A))


def vo_to_odom(T_B_C, T_cam_motion, Ts):
    """Camera motion -> (v, omega) for the EKF."""
    return delta_to_odom(camera_motion_to_base(T_B_C, T_cam_motion), Ts)
