"""LiDAR ICP odometry (Assessment 2, Part A), adapted from 3D KITTI scans to a planar TurtleBot3 scan.

Built on machinevisiontoolbox.PointCloud, spatialmath.SE3 and Open3D, with the same conventions:
  * PointCloud stores points as 3xN columns; scans are Nx3 outside the toolbox.
  * estimate_relative_pose(src, tgt) returns T with  P_target = T * P_source, i.e. the pose of the source
    frame in the target frame. With src = scan at k and tgt = scan at k-1, T is the robot's motion.
  * ICP output drifts from SO(3) numerically, so every result goes through smb.trnorm before SE3().

Planar-scan caveat (new in Track A): a 2D scan lies in the plane z = 0, so PCA normals would all point along z and
point-to-plane would constrain nothing. We therefore extrude the scan vertically (z = -h, 0, +h) before estimating
normals. Walls then give horizontal normals, which is what makes point-to-plane work.
"""
import numpy as np
import open3d as o3d
import spatialmath.base as smb
from spatialmath import SE3
from machinevisiontoolbox import PointCloud
from .utils import wrap


def scan_to_points(angles, ranges, max_range):
    """Polar scan -> Nx3 planar points; drops 'no return' rays (range == max)."""
    ok = ranges < max_range - 1e-6
    a, r = angles[ok], ranges[ok]
    return np.column_stack([r * np.cos(a), r * np.sin(a), np.zeros(ok.sum())])


class ICPOdometry:
    def __init__(self, voxel_size=0.05, max_correspondence_distance=0.5, max_iteration=60,
                 method="plane", min_range=0.15, max_range=3.4, extrude=0.1):
        self.voxel_size, self.max_corr, self.max_iter = voxel_size, max_correspondence_distance, max_iteration
        self.method, self.min_range, self.max_range, self.extrude = method, min_range, max_range, extrude

    def preprocess_point_cloud(self, points):
        """Nx3 -> filtered, downsampled PointCloud (3xN) with normals (A.1)."""
        pc = PointCloud(np.asarray(points).T)
        norms = np.linalg.norm(pc.points, axis=0)
        pc = pc.select(np.where((norms >= self.min_range) & (norms <= self.max_range))[0])
        if self.voxel_size > 0:
            pc = pc.downsample_voxel(self.voxel_size)
        if self.method == "plane":
            P = pc.points.T
            ext = np.vstack([P + [0, 0, z] for z in (-self.extrude, 0.0, self.extrude)])
            pc = PointCloud(ext.T)
            pc.estimate_normals(radius=max(2 * self.voxel_size, 0.1), max_nn=30)
        return pc

    def estimate_relative_pose(self, src_points, tgt_points, init=None):
        """Returns (SE3 T with P_tgt = T * P_src, fitness, inlier_rmse) (A.2)."""
        src, tgt = self.preprocess_point_cloud(src_points), self.preprocess_point_cloud(tgt_points)
        init = SE3() if init is None else init
        if self.method == "plane":
            est = o3d.pipelines.registration.TransformationEstimationPointToPlane()
            res = o3d.pipelines.registration.registration_icp(
                src.pcd, tgt.pcd, self.max_corr, init.A, est,
                o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=self.max_iter))
            return SE3(smb.trnorm(res.transformation)), res.fitness, res.inlier_rmse
        est = o3d.pipelines.registration.TransformationEstimationPointToPoint()
        res = o3d.pipelines.registration.registration_icp(
            src.pcd, tgt.pcd, self.max_corr, init.A, est,
            o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=self.max_iter))
        return SE3(smb.trnorm(res.transformation)), res.fitness, res.inlier_rmse


def delta_to_odom(T_rel, Ts):
    """SE3 motion over one sample -> (v, omega) for the exact-arc motion model f_uni (arc length, not chord)."""
    dx, dy = T_rel.t[0], T_rel.t[1]
    dth = float(wrap(np.arctan2(T_rel.R[1, 0], T_rel.R[0, 0])))
    chord = np.hypot(dx, dy)
    arc = chord if abs(dth) < 1e-6 else chord * (dth / 2) / np.sin(dth / 2)
    return np.sign(dx if abs(dx) > 1e-9 else 1.0) * arc / Ts, dth / Ts


class ICPOdomSource:
    """Stateful wrapper used inside the control loop: scan k vs scan k-1 -> (v, omega) with a fallback.
    Constant-velocity initial guess (as in A2). Falls back to the wheel odometry if the match is poor."""
    def __init__(self, cfg, angles):
        self.cfg, self.angles = cfg, angles
        self.icp = ICPOdometry(cfg.icp_voxel, cfg.icp_max_corr, cfg.icp_max_iter, cfg.icp_method,
                               max_range=cfg.lidar_max - 0.1)
        self.prev_pts, self.prev_T, self.fallbacks = None, SE3(), 0

    def __call__(self, scan, wheel_odom):
        pts = scan_to_points(self.angles, scan, self.cfg.lidar_max)
        if self.prev_pts is None or len(pts) < 30 or len(self.prev_pts) < 30:
            self.prev_pts = pts
            return wheel_odom, False
        T, fit, rmse = self.icp.estimate_relative_pose(pts, self.prev_pts, init=self.prev_T)
        self.prev_pts = pts
        v_w, w_w = wheel_odom
        v, w = delta_to_odom(T, self.cfg.T)
        # sanity gate against the wheel odometry (blunder rejection, not a replacement for the filter)
        if fit < 0.5 or abs(v - v_w) > 0.15 or abs(w - w_w) > 1.0:
            self.fallbacks += 1
            self.prev_T = SE3()
            return wheel_odom, False
        self.prev_T = T
        return (v, w), True
