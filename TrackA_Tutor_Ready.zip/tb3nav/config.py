"""All tunable parameters in one place (quote these on the project page).

Notation follows the Assessment 3 notebook: T sample time, Q_D process noise per sample,
R_N sensor noise, F / H Jacobians. Poses are handled as SE(3) (Assessment 2 convention).
"""
from dataclasses import dataclass, field
import numpy as np


@dataclass
class Config:
    # ---------------- timing / limits (TurtleBot3 Burger) ----------------
    T: float = 0.1                        # sample time [s]
    t_max: float = 150.0                  # trial timeout [s]
    v_ref: float = 0.15                   # cruise speed [m/s]
    v_max: float = 0.22
    omega_max: float = 2.84
    robot_radius: float = 0.11
    wheel_sep: float = 0.160              # [m]
    wheel_radius: float = 0.033           # [m]
    seed: int = 41014                     # robot stream = seed, sensor stream = seed + 1 (as in A3)

    # ---------------- world ----------------
    room: tuple = (-3.0, 3.0, -3.0, 3.0)
    obstacles: tuple = ((-0.5, 0.8, 0.35), (0.8, -0.9, 0.40),
                        (-1.5, -1.2, 0.30), (1.2, 1.5, 0.30))        # x, y, r
    # ArUco markers on the walls: id -> (x, y, nu) with nu = world yaw of the marker normal
    # (the direction the marker faces, i.e. into the room). id 0 is the charging station.
    landmarks: dict = field(default_factory=lambda: {
        0: (3.0, 0.0, np.pi),                                           # charging station (east wall)
        1: (-3.0, 1.5, 0.0), 2: (0.0, 3.0, -np.pi / 2), 3: (0.0, -3.0, np.pi / 2),
        4: (3.0, -2.0, np.pi), 5: (-3.0, -1.5, 0.0), 6: (-2.0, 3.0, -np.pi / 2), 7: (2.0, 3.0, -np.pi / 2),
        8: (-2.0, -3.0, np.pi / 2), 9: (2.0, -3.0, np.pi / 2), 10: (3.0, 2.0, np.pi)})
    marker_size: float = 0.30             # [m] side length
    marker_height: float = 0.15           # [m] centre height above the floor
    dock_pose: tuple = (2.4, 0.0, 0.0)
    approach_pt: tuple = (1.8, 0.0)
    X0_NOMINAL: tuple = (-2.2, -2.0, 0.5)   # where the robot is TOLD it starts (path is planned from here)
    P0_std: tuple = (0.20, 0.20, np.deg2rad(8.0))   # how sure it is (true start is drawn from this)

    # ---------------- camera (pinhole, calibrated intrinsics) ----------------
    f_px: float = 320.0                   # wide-angle: 90 deg horizontal FOV
    image_size: tuple = (640, 480)
    cam_in_base: tuple = (0.05, 0.0, 0.15)  # camera origin in the base frame [m]
    cam_range: float = 5.0
    cam_max_view_angle: float = np.deg2rad(70.0)   # marker normal vs line of sight
    sigma_px: float = 0.5                 # corner detector noise [px]
    p_drop: float = 0.05                  # random missed detection
    px_margin: float = 5.0

    # ---------------- other sensors (TRUE noise used by the simulator) ----------------
    enc_sigma_v: float = 0.01
    enc_sigma_w: float = 0.02
    act_sigma_v: float = 0.005
    act_sigma_w: float = 0.010
    wheel_error: float = 0.04             # worn-wheel mismatch -> constant yaw bias d = v*err/wheel_sep
    lidar_n: int = 360
    lidar_max: float = 3.5
    lidar_sigma: float = 0.01

    # ---------------- EKF (what the FILTER assumes) ----------------
    ekf_sigma_v: float = 0.02             # odometry noise per sample, mapped through G = df/du
    ekf_sigma_w: float = 0.05
    q_floor: tuple = (1e-6, 1e-6, np.deg2rad(0.5) ** 2)   # unmodelled drift per sample (wheel disturbance)
    r_scale: float = 1.0                  # multiplies the calibrated R_N (R_x0.1 / R_x10 ablation)
    gate: bool = True                     # chi-square gate on each marker update
    meas_mode: str = "rb"                 # "rb" = range+bearing, "pose" = range+bearing+marker heading
    odom_source: str = "wheel"            # "wheel" encoders or "icp" LiDAR scan matching
    icp_sigma_v: float = 0.02             # process noise assumed when the ICP is the odometry source
    icp_sigma_w: float = 0.015

    # ---------------- controller (Bryson's rule limits, see control.py) ----------------
    ey_max: float = 0.10                  # largest acceptable cross-track error [m] (docking corridor)
    eth_max: float = np.deg2rad(10.0)
    domega_max: float = 1.0               # largest acceptable steering correction [rad/s]
    z_max: float = 0.15                   # integrator state [m s]
    q_scale: float = 1.0                  # scales Bryson Q (sweeps)
    d_slow: float = 0.5                   # start slowing this far from the dock end of the path [m]

    # ---------------- ICP odometry (Assessment 2 pipeline, planar scans) ----------------
    icp_voxel: float = 0.10
    icp_max_corr: float = 0.20
    icp_max_iter: int = 40
    icp_method: str = "plane"             # "plane" (extruded normals) or "point"

    # ---------------- planner / safety layer ----------------
    grid_res: float = 0.1
    inflate: float = 0.38
    safety_dist: float = 0.30
