"""Path-following controller (Assessment 3 Part A) on the cross-track / heading error model.

e = [e_y, e_theta]:  e_y' = v sin(e_theta),  e_theta' = omega - v kappa cos(e_theta) / (1 - kappa e_y)
Command split:  omega = v*kappa (feedforward) + d_omega (feedback),  d_omega = -K e.
Controllers only ever see errors computed from the pose they are handed (estimate in LQG).
"""
import numpy as np
import control as ct
from .utils import wrap


# ------------------------------ error model ------------------------------
def error_model(v, kappa, Ts):
    """Linearise at e = 0, d_omega = 0 and discretise with a zero-order hold. Returns (Ad, Bd).
    The kappa term does not vanish from A on a turn: d/de_y [-v k cos(e_th)/(1-k e_y)] = -v k^2."""
    A = np.array([[0.0, v], [-v * kappa ** 2, 0.0]])
    B = np.array([[0.0], [1.0]])
    sd = ct.c2d(ct.ss(A, B, np.eye(2), np.zeros((2, 1))), Ts, method="zoh")
    return sd.A, sd.B


def bryson(cfg, integral=False):
    """Bryson's rule: Q_ii = 1/(largest acceptable x_i)^2, R = 1/(largest acceptable u)^2.
    'Acceptable' for a docking corridor: 10 cm cross-track, 10 deg heading, 1 rad/s steering correction."""
    d = [1 / cfg.ey_max ** 2, 1 / cfg.eth_max ** 2] + ([1 / cfg.z_max ** 2] if integral else [])
    return cfg.q_scale * np.diag(d), np.array([[1 / cfg.domega_max ** 2]])


def augment(Ad, Bd, T):
    """Integrator z_{k+1} = z_k + T e_y,k appended to the error model (A3 Task A.3)."""
    Ai = np.block([[Ad, np.zeros((2, 1))], [np.array([[T, 0.0]]), np.array([[1.0]])]])
    return Ai, np.vstack([Bd, [[0.0]]])


class GainSchedule:
    """Design the gain on the STRAIGHT model for each speed v (cached) and report the turn-model stability.
    Speed varies near the dock, so one K for the whole run would not match the plant it was designed for."""
    def __init__(self, cfg, integral):
        self.cfg, self.integral, self._K, self.turn_stable = cfg, integral, {}, {}

    def K(self, v):
        v = round(max(v, 0.03), 2)                      # v = 0 is uncontrollable (nonholonomic): design at a floor
        if v not in self._K:
            c, T = self.cfg, self.cfg.T
            Ad, Bd = error_model(v, 0.0, T)
            Q, R = bryson(c, self.integral)
            if self.integral:
                Ad, Bd = augment(Ad, Bd, T)
            K, _, _ = ct.dlqr(Ad, Bd, Q, R)
            Ad1, Bd1 = error_model(v, 1 / 2.0, T)       # check on a turn of radius 2 m as in A3
            if self.integral:
                Ad1, Bd1 = augment(Ad1, Bd1, T)
            self.turn_stable[v] = bool(np.all(np.abs(np.linalg.eigvals(Ad1 - Bd1 @ K)) < 1))
            self._K[v] = K
        return self._K[v]


class LQRController:
    def __init__(self, cfg):
        self.cfg, self.sched = cfg, GainSchedule(cfg, integral=False)

    def reset(self):
        pass

    def step(self, e_y, e_theta, kappa, v):
        K = self.sched.K(v)
        omega = v * kappa - (K @ np.array([e_y, e_theta])).item()
        return float(np.clip(omega, -self.cfg.omega_max, self.cfg.omega_max))


class LQIController:
    """LQR + integral action on e_y. The integrator in the code is the one in the model (T * e_y),
    and it is frozen while the command is clipped (anti-windup)."""
    def __init__(self, cfg):
        self.cfg, self.sched, self.z = cfg, GainSchedule(cfg, integral=True), 0.0

    def reset(self):
        self.z = 0.0

    def step(self, e_y, e_theta, kappa, v):
        K = self.sched.K(v)
        raw = v * kappa - (K @ np.array([e_y, e_theta, self.z])).item()
        omega = float(np.clip(raw, -self.cfg.omega_max, self.cfg.omega_max))
        if np.isclose(omega, raw):
            self.z += self.cfg.T * e_y
        return omega


# ------------------------------ path and errors ------------------------------
class Path:
    """Dense reference path with heading, curvature and arc length; computes (e_y, e_theta, kappa, s).
    e_y > 0 when the robot is to the LEFT of the path direction (A3 convention)."""
    def __init__(self, x, y, th, kappa, s):
        self.x, self.y, self.th, self.kappa, self.s = x, y, th, kappa, s
        self.xy = np.column_stack([x, y])
        self.s_end = s[-1]
        self._tree = None

    def _at(self, i, pose):
        dx, dy = pose[0] - self.x[i], pose[1] - self.y[i]
        e_y = -np.sin(self.th[i]) * dx + np.cos(self.th[i]) * dy
        return e_y, float(wrap(pose[2] - self.th[i])), self.kappa[i], self.s[i]

    def errors(self, pose, idx=0, window=120):
        """Progress-based nearest point (monotone index, robust to the path passing near itself).
        Returns (e_y, e_theta, kappa, s, idx)."""
        hi = min(idx + window, len(self.x))
        d = np.hypot(self.x[idx:hi] - pose[0], self.y[idx:hi] - pose[1])
        i = idx + int(np.argmin(d))
        return (*self._at(i, pose), i)

    def errors_along(self, X):
        """Vectorised nearest-point errors for a whole log (evaluation on the TRUE pose)."""
        from scipy.spatial import cKDTree
        if self._tree is None:
            self._tree = cKDTree(self.xy)
        _, ii = self._tree.query(np.asarray(X)[:, :2])
        out = np.array([self._at(i, p) for i, p in zip(ii, X)])
        return out[:, 0], out[:, 1], out[:, 2], out[:, 3]


def speed_command(cfg, d_rem):
    """Cruise, then slow towards the dock end of the path (remaining distance from the estimate)."""
    return cfg.v_ref * float(np.clip(d_rem / cfg.d_slow, 0.2, 1.0))


def lidar_safety(cfg, angles, scan, v, w):
    """Reactive LiDAR layer: slows down and steers away when something is close ahead."""
    front = np.abs(angles) < np.deg2rad(40)
    valid = scan[front] < cfg.lidar_max - 1e-6
    if not np.any(valid):
        return v, w
    dmin = scan[front][valid].min()
    if dmin < cfg.safety_dist:
        v *= float(np.clip((dmin - cfg.robot_radius) / (cfg.safety_dist - cfg.robot_radius), 0, 1))
        left = scan[(angles > 0) & front].mean()
        right = scan[(angles < 0) & front].mean()
        w += 1.0 * np.sign(left - right)
    return v, w
