"""Marker detection -> pose -> (range, bearing, marker heading) measurement, plus noise calibration.

Pipeline (Part B): 4 corner pixels --PnP--> T_C_M --extrinsic T_B_C--> T_B_M -> (r, phi, psi).
  r   = horizontal distance base -> marker centre
  phi = bearing of the marker in the base frame (positive = left)
  psi = yaw of the marker normal in the base frame, so  theta = nu - psi  (nu = known world yaw of the normal)
"""
import json, os
import numpy as np
import cv2
import spatialmath.base as smb
from spatialmath import SE3
from .utils import wrap
from .frames import T_B_C, marker_corners_M

_NOISE_FILE = os.path.join(os.path.dirname(__file__), "vision_noise.json")
# fallback until calibrate_vision.py has been run: sigma = c0 + c1 r + c2 r^2  for (r, phi, psi)
_DEFAULT = {"r": [0.0, 0.0, 0.004], "phi": [0.002, 0.0, 0.0], "psi": [0.03, 0.0, 0.0]}


class NoiseModel:
    """Calibrated R_N(r) = diag(sigma_r(r)^2, sigma_phi(r)^2, sigma_psi(r)^2), polynomial in range."""
    # floors stand in for error sources the pixel-noise Monte Carlo cannot see (extrinsic/intrinsic
    # calibration error, marker detection bias). Re-set them from YOUR scene's measured errors.
    FLOOR = np.array([0.01, 0.005, 0.05])

    def __init__(self, path=_NOISE_FILE):
        self.coef = json.load(open(path)) if os.path.exists(path) else _DEFAULT

    def sigma(self, r):
        raw = np.array([np.polyval(self.coef[k][::-1], r) for k in ("r", "phi", "psi")])
        return np.maximum(raw, self.FLOOR)

    def R(self, r, dims=2, scale=1.0):
        return scale * np.diag(self.sigma(r)[:dims] ** 2)


def detect_pose(cfg, cam, corners_px):
    """PnP on the 4 corners (IPPE_SQUARE). Returns T_C_M as SE3, or None on failure."""
    ok, rvec, tvec = cv2.solvePnP(marker_corners_M(cfg), np.asarray(corners_px, np.float64),
                                  cam.K, None, flags=cv2.SOLVEPNP_IPPE_SQUARE)
    if not ok:
        return None
    Rm, _ = cv2.Rodrigues(rvec)
    return SE3.Rt(smb.trnorm(Rm), tvec.ravel())


def marker_measurement(cfg, T_BC, T_C_M):
    """T_C_M (marker in camera) -> (range, bearing, psi) in the BASE frame (frame management)."""
    T_B_M = T_BC * T_C_M
    p, n = T_B_M.t, T_B_M.R[:, 2]
    return np.array([np.hypot(p[0], p[1]), np.arctan2(p[1], p[0]), np.arctan2(n[1], n[0])])


def measurements_from_corners(cfg, cam, corners):
    """dict id -> corners  =>  (M, 3) array with NaN rows for markers not seen (A3 convention)."""
    T_BC = T_B_C(cfg)
    Z = np.full((len(cfg.landmarks), 3), np.nan)
    for i, c in corners.items():
        T = detect_pose(cfg, cam, c)
        if T is not None:
            Z[i] = marker_measurement(cfg, T_BC, T)
    return Z
