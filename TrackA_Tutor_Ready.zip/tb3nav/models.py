"""Motion and measurement models and their Jacobians (Assessment 3 notation: f, F, Q_D, h, H, R_N)."""
import numpy as np
from .utils import wrap


def f_uni(x, u, T):
    """Exact-arc unicycle step from odometry u = (v, omega). Handles omega ~ 0."""
    v, w = float(u[0]), float(u[1])
    th = float(x[2])
    th_n = th + w * T
    if abs(w) < 1e-6:
        dx, dy = v * T * np.cos(th), v * T * np.sin(th)
    else:
        dx, dy = (v / w) * (np.sin(th_n) - np.sin(th)), (v / w) * (np.cos(th) - np.cos(th_n))
    return np.array([x[0] + dx, x[1] + dy, wrap(th_n)])


def F_uni(x, u, T):
    """Jacobian of f_uni w.r.t. the state (3x3)."""
    v, w = float(u[0]), float(u[1])
    th = float(x[2])
    if abs(w) < 1e-6:
        a, b = -v * T * np.sin(th), v * T * np.cos(th)
    else:
        a = (v / w) * (np.cos(th + w * T) - np.cos(th))
        b = (v / w) * (np.sin(th + w * T) - np.sin(th))
    return np.array([[1, 0, a], [0, 1, b], [0, 0, 1]], float)


def G_uni(x, u, T, eps=1e-6):
    """Jacobian of f_uni w.r.t. the input u = (v, omega) (3x2), by central differences."""
    G = np.zeros((3, 2))
    for j in range(2):
        du = np.zeros(2); du[j] = eps
        d = f_uni(x, np.asarray(u) + du, T) - f_uni(x, np.asarray(u) - du, T)
        d[2] = wrap(d[2])
        G[:, j] = d / (2 * eps)
    return G


def Q_D(x, u, T, sigma_v, sigma_w, q_floor):
    """Process noise per sample. Odometry noise is mapped through G = df/du; the floor covers what
    odometry cannot see (a constant wheel yaw bias of a few deg/s drifts heading by ~q_floor per sample)."""
    G = G_uni(x, u, T)
    return G @ np.diag([sigma_v ** 2, sigma_w ** 2]) @ G.T + np.diag(q_floor)


def h_rb(x, lm):
    """Range and bearing from the base pose to a marker at (mx, my). Returns (2,) and its Jacobian (2x3)."""
    dx, dy = lm[0] - x[0], lm[1] - x[1]
    q = dx * dx + dy * dy
    r = np.sqrt(q)
    z = np.array([r, wrap(np.arctan2(dy, dx) - x[2])])
    H = np.array([[-dx / r, -dy / r, 0.0], [dy / q, -dx / q, -1.0]])
    return z, H


def h_psi(x, lm):
    """Heading of the marker normal in the base frame: psi = nu - theta. Returns (1,) and Jacobian (1x3)."""
    return np.array([wrap(lm[2] - x[2])]), np.array([[0.0, 0.0, -1.0]])


def h_marker(x, lm, mode="rb"):
    z, H = h_rb(x, lm)
    if mode == "pose":
        zp, Hp = h_psi(x, lm)
        return np.r_[z, zp], np.vstack([H, Hp])
    return z, H
