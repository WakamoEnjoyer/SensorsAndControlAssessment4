import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Ellipse
from .utils import wrap


def cov_ellipse(ax, mean, P, n_sigma=2.0, **kw):
    w, V = np.linalg.eigh(P[:2, :2])
    ang = np.degrees(np.arctan2(V[1, 1], V[0, 1]))
    e = Ellipse(mean[:2], 2 * n_sigma * np.sqrt(w[1]), 2 * n_sigma * np.sqrt(w[0]), angle=ang, **kw)
    ax.add_patch(e)
    return e


def draw_world(ax, cfg):
    xmin, xmax, ymin, ymax = cfg.room
    ax.plot([xmin, xmax, xmax, xmin, xmin], [ymin, ymin, ymax, ymax, ymin], "k-", lw=2)
    for cx, cy, r in cfg.obstacles:
        ax.add_patch(Circle((cx, cy), r, color="0.6"))
    for i, (mx, my, nu) in cfg.landmarks.items():
        ax.plot(mx, my, "s", color="tab:green" if i == 0 else "tab:orange", ms=8)
        ax.plot([mx, mx + 0.35 * np.cos(nu)], [my, my + 0.35 * np.sin(nu)], "-", color="tab:orange", lw=1)
    ax.plot(*cfg.dock_pose[:2], "g*", ms=14)
    ax.set_aspect("equal"); ax.set_xlabel("x [m]"); ax.set_ylabel("y [m]")


def trial_figure(cfg, L, path, title="", out=None):
    fig, axs = plt.subplots(2, 2, figsize=(14, 10))
    ax = axs[0, 0]; draw_world(ax, cfg)
    ax.plot(path.x, path.y, ":", color="tab:green", lw=1.2, label="reference path")
    ax.plot(L["x_true"][:, 0], L["x_true"][:, 1], "k-", lw=1.2, label="true (eval only)")
    if L["xh"] is not None:
        ax.plot(L["xh"][:, 0], L["xh"][:, 1], "r-", lw=0.8, alpha=.7, label="EKF estimate")
        for k in range(0, len(L["t"]), 40):
            cov_ellipse(ax, L["xh"][k], L["P"][k], fill=False, ec="r", alpha=.4)
    ax.legend(loc="upper left", fontsize=8); ax.set_title("Trajectory (ellipses: 2-sigma position)")
    t = L["t"]; e_true = path.errors_along(L["x_true"])[0]
    ax = axs[0, 1]
    ax.plot(t, 100 * e_true, "k", lw=1, label="true $e_y$")
    ax.plot(t, 100 * L["ey_est"], "r", lw=.8, alpha=.7, label="estimated $e_y$ (what the controller sees)")
    ax.axhspan(-10, 10, color="tab:green", alpha=.08, label="S1 limit")
    ax.set_xlabel("t [s]"); ax.set_ylabel("cross-track error [cm]"); ax.legend(fontsize=8); ax.grid(alpha=.4)
    ax.set_title("Cross-track error")
    if L["xh"] is not None:
        err = L["x_true"] - L["xh"]; err[:, 2] = wrap(err[:, 2])
        n_seen = np.sum(np.isfinite(L["z"][:, :, 0]), axis=1)
        ax = axs[1, 0]; sig = np.sqrt(L["P"][:, 0, 0] + L["P"][:, 1, 1])
        ax.plot(t, 100 * np.linalg.norm(err[:, :2], axis=1), "tab:blue", label="position error")
        ax.plot(t, 200 * sig, "tab:blue", ls="--", label=r"$2\sigma$ (from P)")
        ax.fill_between(t, 0, ax.get_ylim()[1], where=n_seen == 0, color="0.5", alpha=.25, step="mid", label="no marker")
        ax.set_xlabel("t [s]"); ax.set_ylabel("[cm]"); ax.legend(fontsize=8); ax.grid(alpha=.4)
        ax.set_title("Estimation error and its claimed uncertainty")
        ax = axs[1, 1]
        from .metrics import compute_metrics
        nees = np.array([float(e @ np.linalg.solve(P, e)) for e, P in zip(err, L["P"])])
        ax.semilogy(t, nees, "k", lw=.8)
        ax.axhline(7.815, color="r", ls="--", label=r"$\chi^2_3$ 95%"); ax.axhline(3, color="g", ls=":", label="expected = 3")
        ax.set_xlabel("t [s]"); ax.set_ylabel("NEES"); ax.legend(fontsize=8); ax.grid(alpha=.4)
        ax.set_title(f"NEES (ANEES {nees.mean():.2f})")
    fig.suptitle(title, fontsize=14, fontweight="bold"); fig.tight_layout()
    if out:
        fig.savefig(out, dpi=120); plt.close(fig)
    return fig
