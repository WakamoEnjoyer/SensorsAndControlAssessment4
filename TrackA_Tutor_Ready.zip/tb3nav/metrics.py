"""Evaluation: ATE/RPE on SE3 pose lists (Assessment 2, Part C) and tracking / NEES / spec metrics
(Assessment 3, Part C). Ground truth is used here and only here, for evaluation."""
import numpy as np
import spatialmath.base as smb
from spatialmath import SE3
from scipy.stats import chi2
from .utils import wrap

CHI2_3_95 = float(chi2.ppf(0.95, 3))        # 7.815


def compute_errors(est_poses, gt_poses):
    """ATE and RPE for two lists of SE3 (A2 C.1). RPE composes the error transform and normalises it with trnorm."""
    gt_p = np.array([p.t for p in gt_poses]); est_p = np.array([p.t for p in est_poses])
    ate = np.linalg.norm(est_p - gt_p, axis=1)
    rpe_t, rpe_r = [], []
    for i in range(len(gt_poses) - 1):
        T_gt = gt_poses[i].inv() * gt_poses[i + 1]
        T_est = est_poses[i].inv() * est_poses[i + 1]
        T_err = SE3(smb.trnorm((T_gt.inv() * T_est).A))
        rpe_t.append(np.linalg.norm(T_err.t)); rpe_r.append(np.degrees(T_err.angdist(SE3())))
    return {"ate_rmse": float(np.sqrt(np.mean(ate ** 2))), "ate_per_frame": ate,
            "rpe_trans": np.array(rpe_t), "rpe_rot_deg": np.array(rpe_r),
            "mean_rpe_trans": float(np.mean(rpe_t)), "mean_rpe_rot_deg": float(np.mean(rpe_r))}


def compute_metrics(log, path, cfg, t_skip=5.0):
    """Tracking on the TRUE pose after a start-up transient, docking result, and (if an estimate exists) NEES/NIS."""
    X, t = log["x_true"], log["t"]
    e_y, e_th, _, s = path.errors_along(X)
    sel = t >= t_skip
    m = {"rms_ey": float(np.sqrt(np.mean(e_y[sel] ** 2))), "mean_ey": float(np.mean(e_y[sel])),
         "max_ey": float(np.max(np.abs(e_y[sel])))}
    fb = log["u"][:, 1] - log["v"] * log["kappa"]               # feedback part of the steering command
    m["rms_fb"] = float(np.sqrt(np.mean(fb[sel] ** 2)))
    d = np.array(cfg.dock_pose)
    m["dock_pos_err"] = float(np.hypot(*(X[-1, :2] - d[:2])))
    m["dock_th_err"] = float(abs(wrap(X[-1, 2] - d[2])))
    m["collided"] = bool(log["collided"]); m["min_clearance"] = float(log["min_clearance"])
    m["time"] = float(t[-1]); m["reached"] = bool(log["reached"])
    m["success"] = bool(m["reached"] and m["dock_pos_err"] < 0.05 and m["dock_th_err"] < 0.10 and not m["collided"])
    if log["xh"] is not None:
        err = X - log["xh"]; err[:, 2] = wrap(err[:, 2])
        m["pos_rmse"] = float(np.sqrt(np.mean(np.sum(err[:, :2] ** 2, axis=1))))
        m["th_rmse"] = float(np.sqrt(np.mean(err[:, 2] ** 2)))
        nees = np.array([float(e @ np.linalg.solve(P, e)) for e, P in zip(err, log["P"])])
        m["nees"] = nees; m["anees"] = float(nees.mean()); m["nees_inside"] = float(np.mean(nees <= CHI2_3_95))
        nis = [(d2, k) for step in log["nis"] for (d2, k, ok) in step]
        m["mean_nis"] = float(np.mean([a / k for a, k in nis])) if nis else np.nan   # ideal 1 after normalising by dof
        m["nis_inside"] = float(np.mean([a <= chi2.ppf(0.95, k) for a, k in nis])) if nis else np.nan
        acc = [ok for step in log["nis"] for (_, _, ok) in step]
        m["gate_reject"] = float(1 - np.mean(acc)) if acc else 0.0
        m["n_updates"] = len(acc)
    else:
        for k in ("pos_rmse", "th_rmse", "anees", "nees_inside", "mean_nis", "nis_inside", "gate_reject"):
            m[k] = np.nan
        m["n_updates"] = 0
    return m


# Specification for Track A docking (our own, in the style of A3's S1-S4). Limits are justified on the project page.
SPEC = [("S1", "RMS true cross-track",     "rms_ey",       lambda x: x <= 0.10, "<= 0.10 m",    lambda x: x),
        ("S2", "|mean true cross-track|",  "mean_ey",      lambda x: abs(x) <= 0.05, "<= 0.05 m", abs),
        ("S3", "dock position error",      "dock_pos_err", lambda x: x <= 0.05, "<= 0.05 m",    lambda x: x),
        ("S4", "dock heading error",       "dock_th_err",  lambda x: x <= 0.10, "<= 0.10 rad",  lambda x: x),
        ("S5", "RMS feedback steering",    "rms_fb",       lambda x: x <= 0.50, "<= 0.50 rad/s", lambda x: x),
        ("S6", "NEES inside 95% bound",    "nees_inside",  lambda x: x >= 0.90, ">= 0.90",      lambda x: x)]


def check_spec(m, name=""):
    print(f"Specification check {name}")
    for sid, label, key, ok, lim, show in SPEC:
        val = m.get(key, np.nan)
        if val is None or not np.isfinite(val):
            print(f"  {sid} {label:26s} {'n/a':>9s}   {lim:14s} n/a")
        else:
            print(f"  {sid} {label:26s} {show(val):9.4f}   {lim:14s} {'PASS' if ok(val) else 'FAIL'}")
    print(f"  S7 {'no collision':26s} {'':>9s}   {'':14s} {'FAIL' if m['collided'] else 'PASS'}")
