"""Frame management with SE(3) (spatialmath), as in Assessment 2.

World W: x east, y north, z up.   Base B: x forward, y left, z up.
Camera C (OpenCV): x right, y down, z forward.   Marker M: x right, y up, z toward the viewer.
"""
import numpy as np
import spatialmath.base as smb
from spatialmath import SE3
from machinevisiontoolbox import CentralCamera
from .utils import wrap

R_B_C = np.array([[0, 0, 1], [-1, 0, 0], [0, -1, 0]], float)   # columns = camera axes written in B


def pose2SE3(pose):
    """(x, y, theta) -> SE3 of the base in the world (planar motion)."""
    return SE3(float(pose[0]), float(pose[1]), 0.0) * SE3.Rz(float(pose[2]))


def SE3_to_pose(T):
    """SE3 -> (x, y, theta). Uses trnorm-safe arctan2 on the rotation block."""
    return np.array([T.t[0], T.t[1], np.arctan2(T.R[1, 0], T.R[0, 0])])


def T_B_C(cfg):
    """Camera pose in the base frame (extrinsic calibration)."""
    return SE3.Rt(smb.trnorm(R_B_C), np.array(cfg.cam_in_base))


def T_W_M(cfg, i):
    """Marker i pose in the world: normal (z_M) points into the room at yaw nu, y_M is up."""
    mx, my, nu = cfg.landmarks[i]
    zM = np.array([np.cos(nu), np.sin(nu), 0.0])
    yM = np.array([0.0, 0.0, 1.0])
    xM = np.cross(yM, zM)
    return SE3.Rt(smb.trnorm(np.column_stack([xM, yM, zM])), np.array([mx, my, cfg.marker_height]))


def marker_corners_M(cfg):
    """4x3 marker corners in the marker frame, in the OpenCV/ArUco order TL, TR, BR, BL."""
    s = cfg.marker_size / 2
    return np.array([[-s, s, 0], [s, s, 0], [s, -s, 0], [-s, -s, 0]], float)


def make_camera(cfg):
    """Central (pinhole) camera from the calibrated intrinsics. rho = pixel pitch."""
    rho = 8e-6
    w, h = cfg.image_size
    return CentralCamera(f=cfg.f_px * rho, rho=rho, imagesize=[w, h], pp=[w / 2, h / 2])
