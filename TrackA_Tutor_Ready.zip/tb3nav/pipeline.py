"""Closed-loop runs. Structure follows Assessment 3:
  simulate()      true-state feedback (the deliberate cheat, to test the controller alone; also a log for the EKF)
  run_ekf_offline replay a log through the EKF ("watch" mode)
  simulate_lqg()  the EKF estimate drives the controller. Ground truth is read only for the log.
"""
from dataclasses import replace
import numpy as np
from .config import Config
from .sim import Sim2D
from .ekf import EKFConfig, ekf_step
from .vision import NoiseModel, measurements_from_corners
from .frames import make_camera
from .control import LQRController, LQIController, lidar_safety, speed_command
from .icp_odometry import ICPOdomSource
from .planner import build_reference
from .metrics import compute_metrics
from .utils import wrap

CONDITIONS = {
    "true_state":   dict(mode="true"),
    "nominal":      dict(),
    "lqr":          dict(ctrl="lqr"),
    "pose_meas":    dict(cfg=dict(meas_mode="pose")),
    "noise_x3":     dict(sim=dict(noise_scale=3.0)),
    "R_x0.1":       dict(cfg=dict(r_scale=0.1)),
    "R_x10":        dict(cfg=dict(r_scale=10.0)),
    "cam_dropout":  dict(sim=dict(blackout=((15.0, 45.0),))),
    "slip":         dict(sim=dict(slip=(0.92, 0.95), kick_std=0.05)),
    "slip_retuned": dict(sim=dict(slip=(0.92, 0.95), kick_std=0.05), cfg=dict(ekf_sigma_v=0.06, ekf_sigma_w=0.25)),
    "slip_icp":     dict(sim=dict(slip=(0.92, 0.95), kick_std=0.05), cfg=dict(odom_source="icp")),
    "dead_reck":    dict(mode="dead"),
}


def _setup(cfg, seed, sim_kw):
    rng = np.random.default_rng(seed + 2)                          # start-pose draw, separate from the sim streams
    x_nom = np.array(cfg.X0_NOMINAL, float)
    P0 = np.diag(np.array(cfg.P0_std) ** 2)
    x0 = x_nom + rng.multivariate_normal(np.zeros(3), P0)          # truth differs from what the robot is told
    sim = Sim2D(cfg, x0, seed=seed, **sim_kw)
    path, clr = build_reference(cfg, x_nom[:2], x_nom[2])
    return sim, path, clr, x_nom, P0


def _controller(cfg, kind):
    if not isinstance(kind, str):
        return kind                                                # a controller object (used by the sweeps)
    return LQRController(cfg) if kind == "lqr" else LQIController(cfg)


def _empty_log():
    return {k: [] for k in ["t", "x_true", "xh", "P", "u", "kappa", "v", "z", "odom", "nis", "ey_est", "lidar"]}


def _finish(log, sim, cfg, reached, clr, est):
    L = {k: np.array(v) for k, v in log.items() if k not in ("nis",)}
    if len(log["lidar"]) == 0:
        L.pop("lidar")
    L["nis"] = log["nis"]
    if not est:
        L["xh"] = None; L["P"] = None
    L.update(v=np.array(log["v"]), collided=sim.collided, min_clearance=sim.min_clearance, reached=reached,
             ref_clearance=clr)
    return L


def simulate(cfg=None, ctrl="lqi", seed=0, sim_kw=None, store_scans=False):
    """TRUE-STATE feedback: the controller is handed errors computed from the true pose (cheating on purpose)."""
    cfg = cfg or Config()
    sim, path, clr, x_nom, P0 = _setup(cfg, seed, sim_kw or {})
    controller = _controller(cfg, ctrl); controller.reset()
    cam = make_camera(cfg)
    log, u, idx, hold, reached = _empty_log(), (0.0, 0.0), 0, 0, False
    for k in range(int(cfg.t_max / cfg.T)):
        m = sim.step(u)
        xt = sim.ground_truth()                                    # true-state feedback
        e_y, e_th, kappa, s, idx = path.errors(xt, idx)
        v = speed_command(cfg, path.s_end - s)
        om = controller.step(e_y, e_th, kappa, v)
        v, om = lidar_safety(cfg, sim.lidar_angles, m.lidar, v, om)
        if path.s_end - s < 0.02:
            hold += 1; v = om = 0.0
            if hold > int(1.0 / cfg.T):
                reached = True; break
        u = (v, om)
        Z = measurements_from_corners(cfg, cam, m.corners)
        for key, val in (("t", sim.t), ("x_true", xt), ("u", np.array(u)), ("kappa", kappa), ("v", v),
                         ("z", Z), ("odom", np.array(m.odom)), ("ey_est", e_y)):
            log[key].append(val)
        if store_scans:
            log["lidar"].append(m.lidar)
    return _finish(log, sim, cfg, reached, clr, est=False), path


def run_ekf_offline(cfg, log, odom=None, sigmas=None):
    """Replay recorded odometry and marker measurements through the EKF (A3 Part B 'watch' mode).
    `odom` swaps in another odometry stream (e.g. ICP); `sigmas` = (sigma_v, sigma_w) for that stream."""
    ec = EKFConfig(cfg)
    xh, P = np.array(cfg.X0_NOMINAL, float), np.diag(np.array(cfg.P0_std) ** 2)
    XH, PP, NIS = [], [], []
    odom = log["odom"] if odom is None else odom
    sv, sw = sigmas if sigmas else (None, None)
    for o, Z in zip(odom, log["z"]):
        xh, P, nis = ekf_step(xh, P, o, Z, ec, sv, sw)
        XH.append(xh.copy()); PP.append(P.copy()); NIS.append(nis)
    out = dict(log); out.update(xh=np.array(XH), P=np.array(PP), nis=NIS)
    return out


def simulate_lqg(cfg=None, ctrl="lqi", seed=0, sim_kw=None, no_updates=False):
    """The EKF estimate drives the controller. x_true is kept for the log only: if it appeared in the control
    path the loop would not be LQG (see the control block below)."""
    cfg = cfg or Config()
    sim, path, clr, x_nom, P0 = _setup(cfg, seed, sim_kw or {})
    controller = _controller(cfg, ctrl); controller.reset()
    ec, cam = EKFConfig(cfg), make_camera(cfg)
    icp = ICPOdomSource(cfg, sim.lidar_angles) if cfg.odom_source == "icp" else None
    sv, sw = ((cfg.icp_sigma_v, cfg.icp_sigma_w) if icp else (cfg.ekf_sigma_v, cfg.ekf_sigma_w))
    xh, P = x_nom.copy(), P0.copy()
    log, u, idx, hold, reached = _empty_log(), (0.0, 0.0), 0, 0, False
    for k in range(int(cfg.t_max / cfg.T)):
        m = sim.step(u)                                            # robot moves, sensors are read
        odom = icp(m.lidar, m.odom)[0] if icp else m.odom          # wheel encoders or LiDAR scan matching
        Z = measurements_from_corners(cfg, cam, m.corners)
        if no_updates:
            Z[:] = np.nan
        xh, P, nis = ekf_step(xh, P, odom, Z, ec, sv, sw)          # EKF with the odometry actually measured
        # ------------------ control path: ESTIMATE ONLY ------------------
        e_y, e_th, kappa, s, idx = path.errors(xh, idx)
        d_rem = path.s_end - s
        v = speed_command(cfg, d_rem)
        om = controller.step(e_y, e_th, kappa, v)
        v, om = lidar_safety(cfg, sim.lidar_angles, m.lidar, v, om)
        if d_rem < 0.02:                                           # stop rule uses the estimate too
            hold += 1; v = om = 0.0
            if hold > int(1.0 / cfg.T):
                reached = True; break
        u = (v, om)
        # ------------------ evaluation logging (ground truth allowed here) ------------------
        for key, val in (("t", sim.t), ("x_true", sim.ground_truth()), ("xh", xh.copy()), ("P", P.copy()),
                         ("u", np.array(u)), ("kappa", kappa), ("v", v), ("z", Z), ("odom", np.array(odom)),
                         ("nis", nis), ("ey_est", e_y)):
            log[key].append(val)
    L = _finish(log, sim, cfg, reached, clr, est=True)
    L["icp_fallbacks"] = icp.fallbacks if icp else 0
    return L, path


def run_trial(cond="nominal", seed=0, base_cfg=None):
    """One Monte-Carlo trial of a named condition. Returns (metrics dict, log, path)."""
    spec = CONDITIONS[cond]
    cfg = replace(base_cfg or Config(), **spec.get("cfg", {}))
    ctrl, mode = spec.get("ctrl", "lqi"), spec.get("mode", "lqg")
    if mode == "true":
        L, path = simulate(cfg, ctrl, seed, spec.get("sim"))
    else:
        L, path = simulate_lqg(cfg, ctrl, seed, spec.get("sim"), no_updates=(mode == "dead"))
    m = compute_metrics(L, path, cfg)
    m.update(cond=cond, seed=seed, icp_fallbacks=L.get("icp_fallbacks", 0), ref_clearance=L["ref_clearance"])
    return m, L, path
