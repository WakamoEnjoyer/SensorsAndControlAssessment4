import numpy as np


def wrap(a):
    """Wrap an angle, or an array of angles, to [-pi, pi)."""
    return (np.asarray(a) + np.pi) % (2 * np.pi) - np.pi
