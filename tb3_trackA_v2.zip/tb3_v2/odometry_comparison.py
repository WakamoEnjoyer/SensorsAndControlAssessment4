"""Assessment-2-style comparison of odometry sources against ground truth, on the SAME drive:
wheel dead reckoning, LiDAR ICP point-to-plane, LiDAR ICP point-to-point, and the EKF (wheel odom / ICP odom + markers).
Metrics: ATE RMSE, mean RPE (translation, rotation), compute time. Ground truth is evaluation only.
Usage: python odometry_comparison.py [nominal|slip]"""
import sys, time, os
import numpy as np
import matplotlib.pyplot as plt
from tb3nav.config import Config
from tb3nav.pipeline import simulate, run_ekf_offline
from tb3nav.models import f_uni
from tb3nav.frames import pose2SE3
from tb3nav.icp_odometry import ICPOdometry, scan_to_points, delta_to_odom
from tb3nav.metrics import compute_errors
from tb3nav.utils import wrap

cond = sys.argv[1] if len(sys.argv) > 1 else "nominal"
sim_kw = dict(slip=(0.92, 0.95), kick_std=0.05) if cond == "slip" else {}
cfg = Config(); T = cfg.T
L, path = simulate(cfg, "lqi", seed=0, sim_kw=sim_kw, store_scans=True)
X, n = L["x_true"], len(L["t"])
angles = np.linspace(-np.pi, np.pi, cfg.lidar_n, endpoint=False)
gt = [pose2SE3(x) for x in X]


def integrate(odoms):
    x = X[0].copy(); out = [pose2SE3(x)]
    for o in odoms[1:]:
        x = f_uni(x, o, T); out.append(pose2SE3(x))
    return out


def icp_stream(method, voxel=cfg.icp_voxel, corr=cfg.icp_max_corr):
    icp = ICPOdometry(voxel, corr, cfg.icp_max_iter, method, max_range=cfg.lidar_max - 0.1)
    odoms, times, prev, prevT = [L["odom"][0]], [], scan_to_points(angles, L["lidar"][0], cfg.lidar_max), None
    for k in range(1, n):
        pts = scan_to_points(angles, L["lidar"][k], cfg.lidar_max)
        t0 = time.time(); Trel, fit, _ = icp.estimate_relative_pose(pts, prev, init=prevT); times.append(time.time() - t0)
        v, w = delta_to_odom(Trel, T)
        bad = fit < 0.5 or abs(v - L["odom"][k][0]) > 0.15 or abs(w - L["odom"][k][1]) > 1.0
        odoms.append(L["odom"][k] if bad else (v, w)); prevT = None if bad else Trel; prev = pts
    return np.array(odoms), np.mean(times) * 1000


wheel = integrate(L["odom"])
o_pl, ms_pl = icp_stream("plane"); icp_pl = integrate(o_pl)
o_pp, ms_pp = icp_stream("point"); icp_pp = integrate(o_pp)
ekf_w = run_ekf_offline(cfg, L)
ekf_i = run_ekf_offline(cfg, L, odom=o_pl, sigmas=(cfg.icp_sigma_v, cfg.icp_sigma_w))
ekf_wp = [pose2SE3(x) for x in ekf_w["xh"]]; ekf_ip = [pose2SE3(x) for x in ekf_i["xh"]]

methods = {"wheel dead-reckoning": (wheel, 0.0), "ICP point-to-point": (icp_pp, ms_pp), "ICP point-to-plane": (icp_pl, ms_pl),
           "EKF (wheel odom + markers)": (ekf_wp, 0.0), "EKF (ICP odom + markers)": (ekf_ip, ms_pl)}
res = {k: compute_errors(v[0], gt) for k, v in methods.items()}
lines = [f"Odometry comparison, condition = {cond}, {n} samples, path {np.sum(np.linalg.norm(np.diff(X[:, :2], axis=0), axis=1)):.1f} m",
         f"{'method':28s}| {'ATE RMSE (m)':>12s} | {'RPE trans (mm)':>14s} | {'RPE rot (deg)':>13s} | {'ms/step':>7s}", "-" * 86]
for k, (_, ms) in methods.items():
    r = res[k]
    lines.append(f"{k:28s}| {r['ate_rmse']:12.3f} | {1000*r['mean_rpe_trans']:14.2f} | {r['mean_rpe_rot_deg']:13.3f} | {ms:7.1f}")
txt = "\n".join(lines); print(txt)
os.makedirs("results", exist_ok=True); open(f"results/odometry_comparison_{cond}.txt", "w").write(txt)

fig, axs = plt.subplots(2, 2, figsize=(15, 11)); fig.suptitle(f"Odometry sources versus ground truth ({cond})", fontweight="bold")
cols = {"wheel dead-reckoning": "tab:orange", "ICP point-to-point": "tab:purple", "ICP point-to-plane": "tab:blue",
        "EKF (wheel odom + markers)": "tab:red", "EKF (ICP odom + markers)": "tab:green"}
ax = axs[0, 0]; ax.plot(X[:, 0], X[:, 1], "k--", lw=2.5, label="ground truth")
for k, (p, _) in methods.items():
    xy = np.array([q.t for q in p]); ax.plot(xy[:, 0], xy[:, 1], color=cols[k], lw=1.3, label=f"{k} (ATE {res[k]['ate_rmse']:.2f} m)")
ax.set_aspect("equal"); ax.legend(fontsize=7); ax.grid(ls="--", alpha=.5); ax.set_title("Trajectories")
for ax, key, ttl, sc in ((axs[0, 1], "ate_per_frame", "ATE per frame [m]", 1), (axs[1, 0], "rpe_trans", "RPE translation [mm]", 1000),
                         (axs[1, 1], "rpe_rot_deg", "RPE rotation [deg]", 1)):
    for k in methods:
        y = res[k][key] * sc; ax.plot(np.arange(len(y)), y, color=cols[k], lw=1, alpha=.85, label=k)
    ax.set_title(ttl); ax.grid(ls="--", alpha=.5)
axs[0, 1].legend(fontsize=7); fig.tight_layout(); fig.savefig(f"results/odometry_comparison_{cond}.png", dpi=110)
