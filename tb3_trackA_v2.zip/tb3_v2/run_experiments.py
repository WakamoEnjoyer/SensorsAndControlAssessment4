"""Monte-Carlo evaluation of every condition.  Usage: python run_experiments.py [n_trials=20]
Writes results/all_trials.csv, results/summary.csv, results/spec_pass.csv and one figure per condition."""
import sys, os, time
import numpy as np, pandas as pd
from tb3nav.config import Config
from tb3nav.pipeline import run_trial, CONDITIONS
from tb3nav.plots import trial_figure
from tb3nav.metrics import SPEC

N = int(sys.argv[1]) if len(sys.argv) > 1 else 20
conds = sys.argv[2].split(",") if len(sys.argv) > 2 else list(CONDITIONS)
cfg = Config()
os.makedirs("results", exist_ok=True)
rows = []
for cond in conds:
    t0 = time.time()
    for seed in range(N):
        m, L, path = run_trial(cond, seed)
        m.pop("nees", None)
        rows.append(m)
        if seed == 0:
            from dataclasses import replace
            c = replace(cfg, **CONDITIONS[cond].get("cfg", {}))
            trial_figure(c, L, path, f"{cond} (seed 0)", out=f"results/trial_{cond}.png")
    print(f"done {cond:13s} {time.time()-t0:5.0f}s", flush=True)
df = pd.DataFrame(rows)
df.to_csv("results/all_trials.csv", index=False)
g = df.groupby("cond", sort=False)
summary = pd.DataFrame({
    "success": g["success"].mean(),
    "dock_pos_cm": g["dock_pos_err"].mean() * 100,
    "dock_th_deg": np.degrees(g["dock_th_err"].mean()),
    "rms_ey_cm": g["rms_ey"].mean() * 100,
    "mean_ey_cm": g["mean_ey"].mean() * 100,
    "rms_fb": g["rms_fb"].mean(),
    "pos_rmse_cm": g["pos_rmse"].mean() * 100,
    "ANEES(3)": g["anees"].mean(),
    "NEES_in95": g["nees_inside"].mean(),
    "NIS/dof(1)": g["mean_nis"].mean(),
    "gate_rej": g["gate_reject"].mean(),
    "collisions": g["collided"].sum(),
    "time_s": g["time"].mean(),
}).round(3)
summary.to_csv("results/summary.csv")
passes = {}
for sid, label, key, ok, lim, show in SPEC:
    passes[sid] = g.apply(lambda d: np.mean([ok(x) if np.isfinite(x) else np.nan for x in d[key]]) if d[key].notna().any() else np.nan)
passes["S7"] = g["collided"].apply(lambda s: 1 - s.mean())
spec = pd.DataFrame(passes).round(2)
spec.to_csv("results/spec_pass.csv")
print(f"\nSummary over {N} trials per condition\n"); print(summary.to_string())
print(f"\nFraction of trials meeting each specification line\n"); print(spec.to_string())
open("results/summary.txt", "w").write(summary.to_string() + "\n\n" + spec.to_string())
