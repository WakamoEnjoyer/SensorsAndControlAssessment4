"""Animation for the demo video: true state, EKF estimate, 2-sigma ellipse, and which markers are heard.
Usage: python demo.py [condition] [seed] [--save out.gif]     (record nominal + at least one disturbed condition)"""
import sys
import numpy as np
import matplotlib
if "--save" in sys.argv:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from dataclasses import replace
from tb3nav.config import Config
from tb3nav.pipeline import run_trial, CONDITIONS
from tb3nav.plots import draw_world, cov_ellipse

args = [a for a in sys.argv[1:] if not a.startswith("--") and not a.endswith(".gif")]
cond = args[0] if args else "nominal"; seed = int(args[1]) if len(args) > 1 else 0
m, L, path = run_trial(cond, seed)
cfg = replace(Config(), **CONDITIONS[cond].get("cfg", {}))
print({k: round(float(v), 3) for k, v in m.items() if k in ("dock_pos_err", "dock_th_err", "rms_ey", "anees", "time")}, "success:", m["success"])
fig, ax = plt.subplots(figsize=(7.5, 7.5)); draw_world(ax, cfg)
ax.plot(path.x, path.y, ":", color="tab:green", lw=1, label="reference path")
tl, = ax.plot([], [], "k-", lw=1, label="true (eval only)"); el, = ax.plot([], [], "r--", lw=1, label="EKF estimate")
tp, = ax.plot([], [], "ko"); ep, = ax.plot([], [], "r^")
rays = [ax.plot([], [], color="tab:green", lw=.6, alpha=.7)[0] for _ in cfg.landmarks]
ax.legend(loc="upper left", fontsize=8); txt = ax.text(-2.9, -2.9, "", fontsize=9); ell = []
step = 3


def update(f):
    k = min(f * step, len(L["t"]) - 1)
    tl.set_data(L["x_true"][:k + 1, 0], L["x_true"][:k + 1, 1])
    if L["xh"] is not None:
        el.set_data(L["xh"][:k + 1, 0], L["xh"][:k + 1, 1]); ep.set_data([L["xh"][k, 0]], [L["xh"][k, 1]])
        for e in ell:
            e.remove()
        ell.clear(); ell.append(cov_ellipse(ax, L["xh"][k], L["P"][k], n_sigma=2, fill=False, ec="r"))
    tp.set_data([L["x_true"][k, 0]], [L["x_true"][k, 1]])
    for i, r in enumerate(rays):
        seen = np.isfinite(L["z"][k, i, 0])
        r.set_data(*([[L["x_true"][k, 0], cfg.landmarks[i][0]], [L["x_true"][k, 1], cfg.landmarks[i][1]]] if seen else [[], []]))
    err = np.hypot(*(L["xh"][k, :2] - L["x_true"][k, :2])) * 100 if L["xh"] is not None else np.nan
    txt.set_text(f"{cond}  t={L['t'][k]:.1f}s  markers heard={int(np.sum(np.isfinite(L['z'][k, :, 0])))}  pos err={err:.1f} cm")
    return tl, el, tp, ep


anim = FuncAnimation(fig, update, frames=len(L["t"]) // step + 1, interval=40, repeat=False)
if "--save" in sys.argv:
    i = sys.argv.index("--save"); out = sys.argv[i + 1] if i + 1 < len(sys.argv) else "demo.gif"
    anim.save(out, writer=PillowWriter(fps=20)); print("saved", out)
else:
    plt.show()
