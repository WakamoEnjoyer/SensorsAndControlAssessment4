# Group __ : Track A – LiDAR/Camera Navigation and ArUco Docking (TurtleBot3)

**Team:** <names, student numbers>  **Subject:** 41014 Sensors and Control in Mechatronics Systems, Assessment 4

> Every number below was produced by the bundled 2D simulator (`tb3nav/sim.py`), not by your MuJoCo scene. Re-run
> everything on MuJoCo and replace the tables. The structure, models and analysis carry over; the numbers will not.

## 1. Contributions
| Member | What they designed / implemented / tested |
|---|---|
| <name> | <e.g. Part C: EKF, Q_D/R_N tuning, NEES/NIS analysis> |
| <name> | <e.g. Part A/D: error model, LQR/LQI, sweeps> |
| <name> | <e.g. Part B: camera model, PnP, calibration, MuJoCo integration, video> |

## 2. Generative AI declaration
Tools: Claude (Anthropic). Purpose: <code scaffold, derivation checking, debugging, README structure. Edit to be
truthful for your team.> The team read, ran, modified and tested all code; all reported numbers come from our runs.

## 3. Install and run
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
# follow the install order at the top of requirements.txt
python selfcheck.py             # Jacobians vs finite differences, Q_D SPD, error-model sanity
python calibrate_vision.py      # Part B: marker-measurement noise by Monte Carlo -> tb3nav/vision_noise.json
python analysis.py              # controllability, eigenvalues, offset prediction, observability
python run_experiments.py 20    # 12 conditions x 20 trials -> results/
python odometry_comparison.py nominal ; python odometry_comparison.py slip
python sweeps.py 8              # Q_D, controller weight, speed, ICP voxel studies
python sift_vo_selftest.py      # SIFT visual odometry on a synthetic scene
python demo.py nominal 0        # animation for the video (--save out.gif to export)
```
Ground truth (`Sim2D.ground_truth()`) is read only in the logging block of `pipeline.py` and in `metrics.py`. It is never
passed to `ekf.py`, `control.py` or the stop rule.

## 4. Where each course concept is used
| Concept (Assessment) | Where |
|---|---|
| SE(3) frames, `trnorm`, extrinsic `T_B_C`, frame change of a motion (A2) | `frames.py`, `vision.py`, `sift_vo.py` |
| `CentralCamera` pinhole model, PnP, corner projection (A2, Week 3) | `sim.py` (projection), `vision.py` (pose from corners) |
| Camera noise propagated from pixels, calibrated R_N(r) (A2/A3) | `calibrate_vision.py` -> `vision_noise.json` |
| LiDAR ICP: range filter, voxel, normals, point-to-plane vs point-to-point (A2 Part A, D.1) | `icp_odometry.py` |
| SIFT + Lowe ratio + essential matrix + `decomposeE`, camera-motion convention (A2 Part B) | `sift_vo.py`, `sift_vo_selftest.py` |
| ATE and RPE on SE3 lists (A2 Part C) | `metrics.compute_errors`, `odometry_comparison.py` |
| Constant-velocity ICP initial guess (A2) | `icp_odometry.ICPOdomSource` |
| Path-following error model, linearisation, ZOH with `ct.c2d`, `ct.ctrb` (A3 A.1) | `control.error_model`, `analysis.py` |
| Discrete LQR with `ct.dlqr`, Bryson's rule, stability on straight and turn (A3 A.2) | `control.bryson`, `GainSchedule` |
| LQI with integrator `T*e_y` matching the model, anti-windup by freezing (A3 A.3) | `control.LQIController` |
| Feedforward `v*kappa` + feedback split | `control.py` |
| Exact-arc motion model, F, Q_D from odometry noise (A3 B.1) | `models.py` |
| Range/bearing measurement, finite-difference Jacobian checks (A3 B.2) | `models.py`, `selfcheck.py` |
| Sequential EKF update with `nan` handling, symmetrise P, NIS list (A3 B.3) | `ekf.py` |
| True-state feedback baseline vs LQG, separation principle (A3 C.1, D.2) | `pipeline.simulate` vs `simulate_lqg` |
| NEES/ANEES, chi-square bound, spec table S1-S7 (A3 C.2) | `metrics.py` |
| Designed sweeps spanning a factor of 10, speed study with eigenvalues (A3 D.3, D.4; A2 D.4) | `sweeps.py` |
| Separate random streams for robot and sensors (A3) | `sim.py` (seed, seed+1) |

New in Track A (not in the notebooks): marker-pose measurement with its heading component, planar-scan ICP via vertical
extrusion, progress-based path projection, speed scheduling toward the dock, and a LiDAR reactive safety layer.

## 5. System overview
Frames: world W -> base B -> camera C (OpenCV axes) -> marker M. <Insert your frame diagram.>
State x = [x, y, theta]; input u = (v, omega) from wheel encoders or ICP; measurements per marker: range r, bearing phi
and (optionally) marker heading psi, with theta = nu - psi. Assumptions: planar motion, known marker poses and IDs,
Gaussian noise, camera at a known offset. Layout: 11 markers on the walls (id 0 = charging station), 90 deg camera.

## 6. Part A – Model, controllability, observability
```
A.1 CONTROLLABILITY of the discrete path-following error model (ZOH, T=0.10 s)
  straight       v=0.15 kappa=0.0: rank ctrb = 2/2   eig|Ad| = [1. 1.]
  turn R=2 m     v=0.15 kappa=0.5: rank ctrb = 2/2   eig|Ad| = [1. 1.]
  stopped (v=0)  v=0.00 kappa=0.0: rank ctrb = 1/2   eig|Ad| = [1. 1.]
  v = 0: the lateral error cannot be changed without moving (nonholonomic), so gains are designed at a floor of 0.03 m/s.

A.2/A.3 LQR and LQI closed-loop eigenvalue magnitudes (Bryson: ey<=0.10 m, eth<=10 deg, d_omega<=1.0 rad/s, z<=0.15)
  LQR v=0.10 K=[7.473 4.453]  |eig| straight [0.983 0.568]  turn [0.983 0.568]
  LQR v=0.15 K=[7.442 4.518]  |eig| straight [0.974 0.568]  turn [0.974 0.569]
  LQR v=0.22 K=[7.399 4.607]  |eig| straight [0.962 0.569]  turn [0.962 0.569]
  LQI v=0.10 K=[22.957  4.713  4.898]  |eig| straight [0.975 0.975 0.568]  turn [0.975 0.975 0.568]
  LQI v=0.15 K=[19.365  4.812  4.867]  |eig| straight [0.968 0.968 0.568]  turn [0.968 0.968 0.569]
  LQI v=0.22 K=[16.643  4.933  4.828]  |eig| straight [0.96  0.96  0.569]  turn [0.96  0.96  0.569]

Steady cross-track offset of the proportional controller under the worn wheel (A3 interpretation prompt)
  yaw disturbance d = v*err/W = 0.0375 rad/s;  k_y = 7.442  => predicted e_y,ss = d/k_y = 0.50 cm
  measured mean true cross-track (LQR, true-state feedback, after start-up) = +0.66 cm
  (the sign depends on the sign of the wheel error; the magnitude should agree to within the start-up transient)

C. EKF OBSERVABILITY (stacked [H; HF; ...] over 10 steps, numerical rank, sigma_min/sigma_max)
  one marker, rb, stopped     : rank 2/3, sigma_min/sigma_max = 3.7e-17
  one marker, rb, moving      : rank 3/3, sigma_min/sigma_max = 1.6e-02
  one marker, rb+psi, stopped : rank 3/3, sigma_min/sigma_max = 2.1e-01
  two markers, rb, stopped    : rank 3/3, sigma_min/sigma_max = 3.8e-01
  no marker                   : rank 0/3 (dead reckoning, P grows)
  range+bearing from ONE marker gives 2 numbers for a 3-state pose: unobservable when stopped, weakly observable when moving.
  The marker-heading measurement (psi) makes heading directly observable, but PnP heading is poor at range (see calibrate_vision.py).
```
Interpretation to write in your own words: the discrete error model is controllable whenever v != 0 and uncontrollable
at v = 0, hence a gain floor; the LQR offset under the worn wheel is d/k_y and matched the measurement; one marker with
range+bearing cannot fix a 3-state pose when stopped.

## 7. Part B – Sensing and calibration
`calibrate_vision.py` pushes noisy corner pixels (0.5 px) through the same PnP code the filter uses. Findings (simulated
pixel noise only): range sigma grows roughly with r^2 (1.6 mm at 0.6 m, 12 cm at 5 m) with a small negative bias (-4 cm at
5 m); bearing sigma is flat at about 1 mrad; marker-heading sigma is 0.02 rad close up but about 0.5 rad beyond 4 m, and the
planar PnP ambiguity flips the solution in up to 28% of samples. Floors (r 1 cm, phi 0.005 rad, psi 0.05 rad) in
`vision.NoiseModel` stand in for extrinsic calibration error. <Replace with YOUR measured values from MuJoCo.>

## 8. Part C – Estimation
EKF with exact-arc prediction, Q_D = G diag(sigma_v^2, sigma_w^2) G^T + floor (sigma_v 0.02 m/s, sigma_w 0.05 rad/s, floor for
wheel yaw bias), per-marker sequential update, 99.9% chi-square gate, Joseph form. <Defend these values.>

## 9. Part D – Control
Path-following LQI on [e_y, e_theta, z], Bryson limits 0.10 m, 10 deg, 1 rad/s steering correction, 0.15 m s integrator state, gains
designed on the straight model per speed and checked on a 2 m turn.

## 10. Part E – Results (20 trials per condition)
```
              success  dock_pos_cm  dock_th_deg  rms_ey_cm  mean_ey_cm  rms_fb  pos_rmse_cm  ANEES(3)  NEES_in95  NIS/dof(1)  gate_rej  collisions   time_s
cond                                                                                                                                                       
true_state       1.00        2.106        2.320      1.263      -0.178   0.056          NaN       NaN        NaN         NaN       NaN           0   43.535
nominal          1.00        2.169        2.376      2.848       1.158   0.133        5.301     4.034      0.840       0.449     0.000           0   43.275
lqr              1.00        2.234        1.739      3.331       1.878   0.085        4.788     3.855      0.842       0.466     0.001           0   43.150
pose_meas        1.00        2.211        1.416      2.840       1.122   0.135        5.053     4.046      0.832       0.688     0.010           0   43.260
noise_x3         0.95        2.596        2.961      7.310       5.227   0.161       11.242    53.883      0.270       4.467     0.176           1   46.595
R_x0.1           1.00        2.216        2.663      3.761       0.771   0.135        7.003    20.859      0.401       3.793     0.169           0   43.535
R_x10            1.00        2.220        2.132      2.476       0.763   0.128        5.227     1.241      0.990       0.098     0.000           0   43.250
cam_dropout      0.00      132.123       54.845     57.533      43.090   0.194       68.178    30.691      0.383       3.134     0.082           2   49.905
slip             0.85        9.643        6.306      5.965       3.021   0.148       10.287    18.503      0.408       2.323     0.072           0   46.740
slip_retuned     1.00        2.201        2.499      4.016       1.498   0.154        7.619     4.736      0.776       0.405     0.001           0   46.960
slip_icp         0.95        2.781        2.867      2.306       0.697   0.080        5.181     4.677      0.811       0.675     0.015           0   46.825
dead_reck        0.00      334.525       80.664     94.655      86.874   0.120      112.536    17.837      0.323         NaN     0.000          16  128.645

                S1    S2    S3    S4   S5    S6    S7
cond                                                 
true_state    1.00  1.00  1.00  1.00  1.0   NaN  1.00
nominal       1.00  1.00  1.00  1.00  1.0  0.35  1.00
lqr           1.00  1.00  1.00  1.00  1.0  0.25  1.00
pose_meas     1.00  1.00  1.00  1.00  1.0  0.35  1.00
noise_x3      0.75  0.70  1.00  1.00  1.0  0.00  0.95
R_x0.1        1.00  1.00  1.00  1.00  1.0  0.00  1.00
R_x10         1.00  1.00  1.00  1.00  1.0  1.00  1.00
cam_dropout   0.00  0.00  0.00  0.00  0.9  0.00  0.90
slip          0.90  0.85  0.85  0.85  1.0  0.00  1.00
slip_retuned  1.00  1.00  1.00  1.00  1.0  0.20  1.00
slip_icp      1.00  1.00  1.00  0.95  1.0  0.05  1.00
dead_reck     0.00  0.00  0.00  0.00  1.0  0.15  0.20
```
Conditions: `true_state` = controller on ground truth (the cheat, an upper bound); `nominal` = LQI + EKF; `lqr` = no integrator;
`pose_meas` = range+bearing+marker heading; `noise_x3` = sensors 3x noisier than the filter assumes; `R_x0.1`/`R_x10` = filter
trusts the camera 10x more/less; `cam_dropout` = camera off for 30 s; `slip` = wheel slip and heading kicks; `slip_retuned` =
larger process noise; `slip_icp` = ICP odometry under slip; `dead_reck` = no marker updates.

**Specification** (our own, S1-S7 in `metrics.py`): S1 RMS cross-track <= 0.10 m (equals the Bryson limit), S2 |mean| <= 0.05 m,
S3 dock position <= 0.05 m, S4 dock heading <= 0.10 rad, S5 RMS feedback steering <= 0.5 rad/s, S6 NEES inside 95% >= 0.90,
S7 no collision. **The nominal design meets S1-S5 and S7 in every trial but S6 in only 35% of trials**: ANEES is 4.0, so the
filter is mildly overconfident. The Q_D sweep shows the fix (x3 gives ANEES ~3.0) at the cost of tracking accuracy; we did not
apply it, so the table stays traceable to `config.py`.

### Odometry sources against ground truth (Assessment 2 style, seed 0)
```
Odometry comparison, condition = nominal, 434 samples, path 5.6 m
method                      | ATE RMSE (m) | RPE trans (mm) | RPE rot (deg) | ms/step
--------------------------------------------------------------------------------------
wheel dead-reckoning        |        1.897 |           0.90 |         0.204 |     0.0
ICP point-to-point          |        0.543 |           3.97 |         0.174 |     1.3
ICP point-to-plane          |        0.037 |           1.14 |         0.034 |     4.8
EKF (wheel odom + markers)  |        0.019 |           2.13 |         0.124 |     0.0
EKF (ICP odom + markers)    |        0.015 |           2.09 |         0.068 |     4.8

Odometry comparison, condition = slip, 470 samples, path 5.6 m
method                      | ATE RMSE (m) | RPE trans (mm) | RPE rot (deg) | ms/step
--------------------------------------------------------------------------------------
wheel dead-reckoning        |        1.908 |           1.24 |         0.246 |     0.0
ICP point-to-point          |        0.356 |           3.90 |         0.182 |     1.5
ICP point-to-plane          |        0.346 |           1.23 |         0.046 |     4.4
EKF (wheel odom + markers)  |        0.043 |           2.17 |         0.193 |     0.0
EKF (ICP odom + markers)    |        0.015 |           1.95 |         0.092 |     4.4
```
Figures: `results/odometry_comparison_*.png`, `results/trial_<condition>.png`.

### Designed parameter studies
```
1. EKF process noise Q_D (sigma_v, sigma_w scaled together)
   cond  Qd_scale  success  rms_ey_cm  rms_fb  dock_pos_cm  dock_th_deg  pos_rmse_cm  ANEES  NEES_in95  gate_rej  collisions
nominal       0.1    1.000      2.485   0.127        2.315        2.126        5.644  4.720      0.808     0.001           0
nominal       0.3    1.000      2.497   0.126        2.235        2.229        5.650  4.606      0.802     0.001           0
nominal       1.0    1.000      2.558   0.131        2.023        2.270        5.710  3.256      0.896     0.000           0
nominal       3.0    1.000      3.103   0.143        2.256        2.437        6.278  3.013      0.894     0.000           0
nominal      10.0    1.000      3.716   0.160        2.167        2.573        7.068  2.975      0.881     0.001           0
   slip       0.1    0.750      3.436   0.149        3.971        4.293        8.576 49.833      0.181     0.066           0
   slip       0.3    0.875      3.367   0.149        3.658        3.675        8.411 37.239      0.209     0.058           0
   slip       1.0    0.875      3.411   0.149        3.729        4.395        7.827 12.662      0.449     0.042           0
   slip       3.0    1.000      3.456   0.160        2.183        2.472        7.426  4.368      0.782     0.006           0
   slip      10.0    1.000      3.539   0.175        2.242        2.410        7.518  2.948      0.880     0.000           0

2. LQI cross-track limit in Bryson's rule (smaller limit = heavier weight on e_y), EKF in the loop
 ey_max  success  rms_ey_cm  rms_fb  dock_pos_cm  dock_th_deg  pos_rmse_cm  ANEES  NEES_in95  gate_rej  collisions
   0.03      1.0      2.311   0.179        2.170        2.417        5.740  3.597      0.862       0.0           0
   0.10      1.0      2.558   0.131        2.023        2.270        5.710  3.256      0.896       0.0           0
   0.30      1.0      2.839   0.130        2.126        2.340        5.808  3.741      0.843       0.0           0

3. Speed: closed-loop |eig| of the LQI design, scheduled K(v) vs FIXED K(0.15) (what 'no redesign' means)
  v=0.10 scheduled      straight [0.975 0.975 0.568] turn [0.975 0.975 0.568]
  v=0.10 fixed K(0.15)  straight [0.98 0.98 0.55] turn [0.98 0.98 0.55]
  v=0.15 scheduled      straight [0.968 0.968 0.568] turn [0.968 0.968 0.569]
  v=0.15 fixed K(0.15)  straight [0.968 0.968 0.568] turn [0.968 0.968 0.569]
  v=0.22 scheduled      straight [0.96  0.96  0.569] turn [0.96  0.96  0.569]
  v=0.22 fixed K(0.15)  straight [0.95  0.95  0.598] turn [0.95  0.95  0.598]
   v          gain  success  rms_ey_cm  rms_fb  dock_pos_cm  dock_th_deg  pos_rmse_cm  ANEES  NEES_in95  gate_rej  collisions
0.10     scheduled      1.0      3.473   0.132        1.944        2.844        5.339  3.730      0.870     0.000           0
0.10 fixed K(0.15)      1.0      3.401   0.120        2.202        3.186        5.288  3.471      0.869     0.000           0
0.15     scheduled      1.0      2.460   0.138        1.975        2.528        5.325  2.974      0.893     0.001           0
0.15 fixed K(0.15)      1.0      2.461   0.138        1.974        2.428        5.325  2.973      0.893     0.001           0
0.22     scheduled      1.0      2.451   0.151        2.152        1.596        5.466  3.180      0.876     0.000           0
0.22 fixed K(0.15)      1.0      2.291   0.165        2.129        1.471        5.535  3.399      0.841     0.001           0

4. ICP voxel size: per-step error against truth on one drive (corr. distance 0.2 m)
method  voxel_m  mean_trans_err_mm  mean_rot_err_deg  p95_rot_err_deg  min_fitness  ms_per_scan
 plane     0.03       8.046990e+01            1.3316           1.9885       0.0000      11.7815
 plane     0.05       1.065176e+02            1.6797           2.0254       0.0000       9.1443
 plane     0.10       1.763600e+00            0.0339           0.0844       0.9821       4.5505
 plane     0.20       2.974700e+00            0.0524           0.1356       0.9714       2.8293
 plane     0.40       4.914762e+15            0.0753           0.2032       0.0000       2.1977
 point     0.03       4.956300e+00            0.1875           0.4971       0.9911       1.8017
 point     0.05       5.253900e+00            0.1904           0.5061       0.9891       1.5104
 point     0.10       7.884000e+00            0.1910           0.5110       0.9821       1.4133
 point     0.20       1.509150e+01            0.3197           0.8846       0.9714       1.0559
 point     0.40       1.957520e+01            0.4112           1.3386       0.8378       0.8872
```

## 11. What failed and what we learned (diagnosed from the results above)
1. **Marker coverage, not the filter, decided feasibility.** With 4 markers and a narrow camera at least one marker was visible 41%
   of the time and the robot, with a wrong estimate, drove into an obstacle. The 11-marker layout and 90 deg camera gave 83%.
2. **Wheel odometry cannot see the worn wheel.** Its per-step error is 1 mm but ATE is 1.9 m. ICP point-to-plane sees the true motion.
3. **Slip makes the nominal EKF inconsistent** (ANEES 18); raising Q_D or switching to ICP odometry fixes it.
4. **A 30 s camera blackout defeats the system** (0% success): with only wheel odometry the heading drifts without bound.
5. **ICP fails at fine voxel sizes** because normals estimated from 1 cm-noisy, sparse points are unreliable.
6. **Marker heading from PnP is unreliable beyond about 3 m** (sigma ~0.3-0.5 rad), yet adding it improved docking heading
   (2.4 -> 1.4 deg). Our reading, to verify on your scene: near the dock the heading is accurate (sigma 0.02-0.09 rad within
   2 m) and the range-dependent R(r) down-weights it elsewhere; only 1% of updates were gated out, so the gate is not the reason.

## 12. Hardware (optional)
<If done: show in the video and compare sim vs hardware quantitatively.>

## 13. Limitations and what is untested
* The MuJoCo adapter is a skeleton (`tb3nav/mujoco_adapter.py`); nothing has been run against your scene.
* SIFT VO is tested only on a synthetic wall-and-floor scene (`sift_vo_selftest.py`), not wired into the control loop, because
  the 2D simulator has no images. Key-frames need about 18 cm baselines; scale comes from wheel odometry, which slip corrupts.
* Planar-scan ICP uses a vertical extrusion so normals exist; it is a modelling choice, not a library feature.
* Prior map for planning; LiDAR is used for odometry and a reactive safety layer, not for mapping.
* Known data association (marker IDs), single-hypothesis EKF, no wheel-bias state (an augmented bias state is the natural next step).

## 14. Acknowledgements
Weekly tutorial code, MuJoCo documentation, Robotics Toolbox / Machine Vision Toolbox, python-control, Open3D.
