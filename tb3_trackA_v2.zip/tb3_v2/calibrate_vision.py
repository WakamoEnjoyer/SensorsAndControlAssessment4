"""Part B: calibrate the marker-measurement noise by Monte Carlo through the SAME pipeline the filter uses.

Samples robot poses around a wall marker, projects the corners, adds pixel noise, runs PnP -> (r, phi, psi),
compares with the exact geometry and fits sigma(r) = c0 + c1 r + c2 r^2. Writes tb3nav/vision_noise.json.
"""
import json, numpy as np
from tb3nav.config import Config
from tb3nav.frames import pose2SE3, T_B_C, T_W_M, make_camera, marker_corners_M
from tb3nav.vision import detect_pose, marker_measurement, _NOISE_FILE
from tb3nav.utils import wrap

cfg = Config()
cam, TBC, rng = make_camera(cfg), T_B_C(cfg), np.random.default_rng(0)
i = 0
mx, my, nu = cfg.landmarks[i]
TWM = T_W_M(cfg, i)
Pw = TWM * marker_corners_M(cfg).T
bins = np.arange(0.6, 5.01, 0.4)
rows = []
for r0 in bins:
    errs = []
    for _ in range(600):
        r = r0 + rng.uniform(-0.2, 0.2)
        view = rng.uniform(-np.deg2rad(50), np.deg2rad(50))        # angle of robot position about the marker normal
        px, py = mx + r * np.cos(nu + view), my + r * np.sin(nu + view)
        th = np.arctan2(my - py, mx - px) + rng.uniform(-np.deg2rad(20), np.deg2rad(20))   # roughly facing it
        pose = np.array([px, py, th])
        T_W_C = pose2SE3(pose) * TBC
        uv = cam.project_point(Pw, pose=T_W_C)
        if uv[0].min() < 5 or uv[0].max() > 635 or uv[1].min() < 5 or uv[1].max() > 475 or np.any((T_W_C.inv() * Pw)[2] < 0.1):
            continue
        uvn = uv.T + rng.normal(0, cfg.sigma_px, (4, 2))
        T = detect_pose(cfg, cam, uvn)
        z = marker_measurement(cfg, TBC, T)
        dx, dy = mx - px, my - py
        zt = np.array([np.hypot(dx, dy), wrap(np.arctan2(dy, dx) - th), wrap(nu - th)])
        e = z - zt; e[1:] = wrap(e[1:])
        errs.append(np.r_[np.hypot(dx, dy), e])
    errs = np.array(errs)
    rows.append((r0, len(errs), errs[:, 1].mean(), errs[:, 1].std(), errs[:, 2].mean(), errs[:, 2].std(),
                 errs[:, 3].mean(), errs[:, 3].std(), np.mean(np.abs(errs[:, 3]) > 0.3)))
rows = np.array(rows)
print(f"{'range':>6} {'n':>4} | {'bias r':>8} {'sd r [m]':>9} | {'bias phi':>9} {'sd phi [rad]':>12} | {'bias psi':>9} {'sd psi [rad]':>12} | {'psi flips':>9}")
for r in rows:
    print(f"{r[0]:6.1f} {int(r[1]):4d} | {r[2]:8.4f} {r[3]:9.4f} | {r[4]:9.4f} {r[5]:12.4f} | {r[6]:9.4f} {r[7]:12.4f} | {r[8]:9.2f}")
rr = rows[:, 0]
coef = {"r": np.polyfit(rr, rows[:, 3], 2)[::-1].tolist(),
        "phi": np.polyfit(rr, rows[:, 5], 2)[::-1].tolist(),
        "psi": np.polyfit(rr, rows[:, 7], 2)[::-1].tolist()}
json.dump(coef, open(_NOISE_FILE, "w"), indent=1)
print("saved", _NOISE_FILE, coef)
