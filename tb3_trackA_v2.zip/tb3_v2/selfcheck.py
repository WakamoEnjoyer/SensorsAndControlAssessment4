"""Checkpoint (Assessment 3 style): Jacobians vs finite differences, shapes, error model sanity.
Run before anything else:  python selfcheck.py"""
import numpy as np
import control as ct
from tb3nav.config import Config
from tb3nav.models import f_uni, F_uni, h_rb, h_psi, Q_D
from tb3nav.control import error_model
from tb3nav.utils import wrap

cfg = Config(); T = cfg.T
rng = np.random.default_rng(0)
for _ in range(10):
    x = np.array([rng.uniform(-2, 2), rng.uniform(-2, 2), rng.uniform(-np.pi, np.pi)])
    u = (rng.uniform(0.05, 0.2), rng.choice([0.0, rng.uniform(-1, 1)]))
    lm = cfg.landmarks[rng.integers(4)]
    F = F_uni(x, u, T)
    fdF = np.array([wrap(f_uni(x + d, u, T) - f_uni(x - d, u, T)) / 2e-6 for d in 1e-6 * np.eye(3)]).T
    assert np.allclose(F, fdF, atol=1e-5), "F_uni disagrees with finite differences"
    z, H = h_rb(x, lm)
    fdH = np.array([wrap(h_rb(x + d, lm)[0] - h_rb(x - d, lm)[0]) / 2e-6 for d in 1e-6 * np.eye(3)]).T
    assert H.shape == (2, 3) and np.allclose(H, fdH, atol=1e-5), "H_rb disagrees with finite differences"
    zp, Hp = h_psi(x, lm)
    fdHp = np.array([wrap(h_psi(x + d, lm)[0] - h_psi(x - d, lm)[0]) / 2e-6 for d in 1e-6 * np.eye(3)]).T
    assert Hp.shape == (1, 3) and np.allclose(Hp, fdHp, atol=1e-5), "H_psi disagrees with finite differences"
    Q = Q_D(x, u, T, cfg.ekf_sigma_v, cfg.ekf_sigma_w, cfg.q_floor)
    assert np.allclose(Q, Q.T) and np.all(np.linalg.eigvalsh(Q) > 0), "Q_D must be symmetric positive definite"
Ad0, Bd0 = error_model(cfg.v_ref, 0.0, T)
Ad1, Bd1 = error_model(cfg.v_ref, 0.5, T)
assert Ad0.shape == (2, 2) and Bd0.shape == (2, 1)
assert np.allclose(np.abs(np.linalg.eigvals(Ad0)), 1.0, atol=1e-6), "straight error model is a double integrator"
assert not np.allclose(Ad0, Ad1), "curvature term missing from A"
print("selfcheck OK: Jacobians match finite differences, Q_D is SPD, error model is sane")
