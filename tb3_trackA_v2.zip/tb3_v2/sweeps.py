"""Designed parameter studies (Assessment 3 D.3 / D.4 and Assessment 2 D.4).  Usage: python sweeps.py [n_seeds=8]
  1. EKF process noise Q_D scale (x0.1 .. x10) with and without wheel slip -> spec lines, ANEES, tracking
  2. Controller weight: Bryson e_y limit (x10 span) -> tracking error vs control effort
  3. Speed: closed-loop eigenvalues at 3 speeds, scheduled vs FIXED gain designed at 0.15 m/s, plus simulation
  4. ICP voxel size: translation and rotation accuracy against runtime, point-to-plane vs point-to-point"""
import sys, time, os
import numpy as np, pandas as pd
from dataclasses import replace
from tb3nav.config import Config
from tb3nav.pipeline import simulate_lqg, simulate, run_trial, CONDITIONS
from tb3nav.control import LQIController, error_model, augment, GainSchedule
from tb3nav.metrics import compute_metrics, SPEC
from tb3nav.icp_odometry import ICPOdometry, scan_to_points, delta_to_odom
from tb3nav.frames import pose2SE3

NS = int(sys.argv[1]) if len(sys.argv) > 1 else 8
base = Config(); os.makedirs("results", exist_ok=True)
out = []


def agg(cfg, ctrl="lqi", sim_kw=None, seeds=range(NS)):
    ms = []
    for s in seeds:
        L, path = simulate_lqg(cfg, ctrl, s, sim_kw)
        ms.append(compute_metrics(L, path, cfg))
    d = pd.DataFrame(ms)
    return dict(success=d.success.mean(), rms_ey_cm=100 * d.rms_ey.mean(), rms_fb=d.rms_fb.mean(), dock_pos_cm=100 * d.dock_pos_err.mean(),
                dock_th_deg=np.degrees(d.dock_th_err.mean()), pos_rmse_cm=100 * d.pos_rmse.mean(), ANEES=d.anees.mean(),
                NEES_in95=d.nees_inside.mean(), gate_rej=d.gate_reject.mean(), collisions=int(d.collided.sum()))


# ---- 1. process noise sweep ----
out.append("1. EKF process noise Q_D (sigma_v, sigma_w scaled together)")
rows = []
for cond, kw in (("nominal", {}), ("slip", dict(slip=(0.92, 0.95), kick_std=0.05))):
    for sc in (0.1, 0.3, 1.0, 3.0, 10.0):
        c = replace(base, ekf_sigma_v=base.ekf_sigma_v * sc, ekf_sigma_w=base.ekf_sigma_w * sc)
        rows.append(dict(cond=cond, Qd_scale=sc, **agg(c, sim_kw=kw)))
        print("  Q_D", cond, sc, flush=True)
t1 = pd.DataFrame(rows).round(3); out.append(t1.to_string(index=False))

# ---- 2. controller weight ----
out.append("\n2. LQI cross-track limit in Bryson's rule (smaller limit = heavier weight on e_y), EKF in the loop")
rows = []
for ey in (0.03, 0.1, 0.3):
    rows.append(dict(ey_max=ey, **agg(replace(base, ey_max=ey))))
    print("  LQI", ey, flush=True)
out.append(pd.DataFrame(rows).round(3).to_string(index=False))

# ---- 3. speed sweep ----
out.append("\n3. Speed: closed-loop |eig| of the LQI design, scheduled K(v) vs FIXED K(0.15) (what 'no redesign' means)")
sch = GainSchedule(base, True); K15 = sch.K(0.15)
for v in (0.10, 0.15, 0.22):
    for name, K in (("scheduled", sch.K(v)), ("fixed K(0.15)", K15)):
        res = []
        for kap in (0.0, 0.5):
            Ad, Bd = augment(*error_model(v, kap, base.T), base.T)
            res.append(np.round(np.sort(np.abs(np.linalg.eigvals(Ad - Bd @ K)))[::-1], 3))
        out.append(f"  v={v:.2f} {name:14s} straight {res[0]} turn {res[1]}")


class FixedLQI(LQIController):
    def __init__(self, cfg, K):
        super().__init__(cfg)
        class S:                                   # constant-gain schedule
            def K(self_, v): return K
        self.sched = S()


rows = []
for v in (0.10, 0.15, 0.22):
    c = replace(base, v_ref=v)
    for name, mk in (("scheduled", lambda c=c: "lqi"), ("fixed K(0.15)", lambda c=c: FixedLQI(c, K15))):
        rows.append(dict(v=v, gain=name, **agg(c, ctrl=mk(), seeds=range(max(NS // 2, 3)))))
out.append(pd.DataFrame(rows).round(3).to_string(index=False))
print("  speed done", flush=True)

# ---- 4. ICP voxel sweep (rotation focus, as in A2 D.4) ----
out.append("\n4. ICP voxel size: per-step error against truth on one drive (corr. distance 0.2 m)")
L, _ = simulate(base, "lqi", 0, None, store_scans=True)
X = L["x_true"]; ang = np.linspace(-np.pi, np.pi, base.lidar_n, endpoint=False)
rows = []
for method in ("plane", "point"):
    for vox in (0.03, 0.05, 0.1, 0.2, 0.4):
        icp = ICPOdometry(vox, 0.2, 40, method, max_range=base.lidar_max - 0.1)
        times = []
        er_t, er_r, fits = [], [], []
        prev = scan_to_points(ang, L["lidar"][0], base.lidar_max)
        for k in range(1, len(X)):
            pts = scan_to_points(ang, L["lidar"][k], base.lidar_max)
            t0 = time.time(); T, fit, _ = icp.estimate_relative_pose(pts, prev); times.append(time.time() - t0); prev = pts
            Tg = pose2SE3(X[k - 1]).inv() * pose2SE3(X[k])
            Te = Tg.inv() * T
            er_t.append(np.linalg.norm(Te.t)); er_r.append(np.degrees(abs(np.arctan2(Te.R[1, 0], Te.R[0, 0])))); fits.append(fit)
        rows.append(dict(method=method, voxel_m=vox, mean_trans_err_mm=1000 * np.mean(er_t), mean_rot_err_deg=np.mean(er_r),
                         p95_rot_err_deg=np.percentile(er_r, 95), min_fitness=np.min(fits), ms_per_scan=1000 * np.mean(times)))
        print("  ICP", method, vox, flush=True)
out.append(pd.DataFrame(rows).round(4).to_string(index=False))
txt = "\n".join(out); print("\n" + txt); open("results/sweeps.txt", "w").write(txt)
