"""Self-test of the SIFT VO module on a synthetic scene (textured wall + floor), because the 2D simulator has no images.
Checks the A2 sign convention and reports ATE/RPE. Run:  python sift_vo_selftest.py"""
import numpy as np, cv2
from spatialmath import SE3
from tb3nav.config import Config
from tb3nav.frames import make_camera, T_B_C, pose2SE3
from tb3nav.sift_vo import SIFTOdometry, camera_motion_to_base
from tb3nav.metrics import compute_errors

cfg = Config(); cam = make_camera(cfg); TBC = T_B_C(cfg)
rng = np.random.default_rng(1)
W, H = cfg.image_size
K = cam.K
Kinv = np.linalg.inv(K)
uu, vv = np.meshgrid(np.arange(W), np.arange(H))
rays_c = (Kinv @ np.stack([uu.ravel(), vv.ravel(), np.ones(W * H)]))      # 3 x HW, camera frame


def texture(n=2048):
    t = np.zeros((n, n), np.float32)
    for s, a in ((1.5, 1.0), (4, 1.0), (12, 0.7)):
        t += a * cv2.GaussianBlur(rng.standard_normal((n, n)).astype(np.float32), (0, 0), s) * s
    t = (t - t.min()) / (t.max() - t.min())
    return (255 * t).astype(np.uint8)


TEX_WALL, TEX_FLOOR, PX_PER_M = texture(), texture(), 200.0


def render(T_W_C, x_wall=6.0):
    """Ray-cast a wall at x = x_wall and the floor z = 0, sample their textures."""
    d = T_W_C.R @ rays_c; o = T_W_C.t
    with np.errstate(divide="ignore", invalid="ignore"):
        tw = np.where(d[0] > 1e-9, (x_wall - o[0]) / d[0], np.inf)
        tf = np.where(d[2] < -1e-9, (0 - o[2]) / d[2], np.inf)
    use_wall = tw < tf
    t = np.where(use_wall, tw, tf)
    P = o[:, None] + d * t
    n = TEX_WALL.shape[0]
    uw = ((P[1] * PX_PER_M + n / 2) % n).astype(np.float32); vw = ((P[2] * PX_PER_M + 200) % n).astype(np.float32)
    uf = ((P[0] * PX_PER_M + n / 2) % n).astype(np.float32); vf = ((P[1] * PX_PER_M + n / 2) % n).astype(np.float32)
    img_w = cv2.remap(TEX_WALL, uw.reshape(H, W), vw.reshape(H, W), cv2.INTER_LINEAR)
    img_f = cv2.remap(TEX_FLOOR, uf.reshape(H, W), vf.reshape(H, W), cv2.INTER_LINEAR)
    return np.where(use_wall.reshape(H, W), img_w, img_f).astype(np.uint8)


# drive forward with a gentle left turn, one key-frame every 'skip' samples (small baselines need key-frames)
skip, n_kf = 12, 14
poses, x = [], np.array([0.0, 0.0, 0.0])
for k in range(n_kf * skip + 1):
    poses.append(x.copy()); x = x + np.array([0.015 * np.cos(x[2]), 0.015 * np.sin(x[2]), 0.012])
kf = poses[::skip]
imgs = [render(pose2SE3(p) * TBC) for p in kf]
vo = SIFTOdometry(cam, nfeatures=1500, ratio_thresh=0.75)

est, gt = [pose2SE3(kf[0])], [pose2SE3(kf[0])]
fwd = []
for i in range(len(kf) - 1):
    T_gt_B = pose2SE3(kf[i]).inv() * pose2SE3(kf[i + 1])
    scale = np.linalg.norm((TBC.inv() * T_gt_B * TBC).t)          # wheel-odometry scale in a real run
    Tc, inl, info = vo.estimate_relative_pose(imgs[i], imgs[i + 1], scale=scale)
    Tb = camera_motion_to_base(TBC, Tc)
    est.append(est[-1] * Tb); gt.append(pose2SE3(kf[i + 1])); fwd.append(Tc.t[2])
print(f"camera-frame forward (Z) translation per key-frame: mean {np.mean(fwd):+.3f} m  (must be POSITIVE for forward motion)")
assert np.mean(fwd) > 0, "sign convention wrong: do not invert decomposeE's result"
m = compute_errors(est, gt)
print(f"key-frames {len(kf)} (baseline {0.015*skip:.2f} m) | ATE RMSE {m['ate_rmse']:.3f} m | mean RPE trans {m['mean_rpe_trans']*100:.2f} cm "
      f"| median RPE rot {np.median(m['rpe_rot_deg']):.2f} deg, mean {m['mean_rpe_rot_deg']:.2f} deg | path length {sum(np.linalg.norm((gt[i].inv()*gt[i+1]).t) for i in range(len(gt)-1)):.2f} m")
