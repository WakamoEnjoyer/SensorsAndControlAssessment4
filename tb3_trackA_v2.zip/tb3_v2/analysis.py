"""Part A / Part C analysis (Assessment 3 style): controllability, closed-loop eigenvalues, the LQR steady offset
prediction, and EKF observability.  Output -> results/analysis.txt"""
import numpy as np, control as ct, os
from tb3nav.config import Config
from tb3nav.control import error_model, bryson, augment, GainSchedule
from tb3nav.models import h_marker
from tb3nav.pipeline import simulate
from tb3nav.metrics import compute_metrics

cfg = Config(); T = cfg.T
out = []
out.append("A.1 CONTROLLABILITY of the discrete path-following error model (ZOH, T=%.2f s)" % T)
for name, v, kap in (("straight", cfg.v_ref, 0.0), ("turn R=2 m", cfg.v_ref, 0.5), ("stopped (v=0)", 0.0, 0.0)):
    Ad, Bd = error_model(v, kap, T)
    out.append(f"  {name:14s} v={v:.2f} kappa={kap:.1f}: rank ctrb = {np.linalg.matrix_rank(ct.ctrb(Ad, Bd))}/2   eig|Ad| = {np.round(np.abs(np.linalg.eigvals(Ad)), 4)}")
out.append("  v = 0: the lateral error cannot be changed without moving (nonholonomic), so gains are designed at a floor of 0.03 m/s.")

out.append("\nA.2/A.3 LQR and LQI closed-loop eigenvalue magnitudes (Bryson: ey<=%.2f m, eth<=%.0f deg, d_omega<=%.1f rad/s, z<=%.2f)"
           % (cfg.ey_max, np.degrees(cfg.eth_max), cfg.domega_max, cfg.z_max))
for integral in (False, True):
    sch = GainSchedule(cfg, integral)
    for v in (0.10, 0.15, 0.22):
        K = sch.K(v)
        res = []
        for kap in (0.0, 0.5):
            Ad, Bd = error_model(v, kap, T)
            if integral:
                Ad, Bd = augment(Ad, Bd, T)
            res.append(np.round(np.sort(np.abs(np.linalg.eigvals(Ad - Bd @ K)))[::-1], 3))
        out.append(f"  {'LQI' if integral else 'LQR'} v={v:.2f} K={np.round(K.ravel(), 3)}  |eig| straight {res[0]}  turn {res[1]}")

out.append("\nSteady cross-track offset of the proportional controller under the worn wheel (A3 interpretation prompt)")
sch = GainSchedule(cfg, False)
d = cfg.v_ref * cfg.wheel_error / cfg.wheel_sep
ky = float(sch.K(cfg.v_ref)[0, 0])
Lr, pr = simulate(cfg, "lqr", seed=0, sim_kw=dict(slip=(1, 1)))
m = compute_metrics(Lr, pr, cfg)
out.append(f"  yaw disturbance d = v*err/W = {d:.4f} rad/s;  k_y = {ky:.3f}  => predicted e_y,ss = d/k_y = {100*d/ky:.2f} cm")
out.append(f"  measured mean true cross-track (LQR, true-state feedback, after start-up) = {100*m['mean_ey']:+.2f} cm")
out.append("  (the sign depends on the sign of the wheel error; the magnitude should agree to within the start-up transient)")

out.append("\nC. EKF OBSERVABILITY (stacked [H; HF; ...] over 10 steps, numerical rank, sigma_min/sigma_max)")
from tb3nav.models import F_uni
def obs(x, u, lms, mode):
    rows, Phi = [], np.eye(3)
    F = F_uni(x, u, T)
    H = np.vstack([h_marker(x, cfg.landmarks[i], mode)[1] for i in lms])
    for _ in range(10):
        rows.append(H @ Phi); Phi = F @ Phi
    sv = np.linalg.svd(np.vstack(rows), compute_uv=False)
    return int(np.sum(sv > 1e-6 * sv[0])), sv[-1] / sv[0]
x = np.array([-1.0, -1.0, 0.4])
for name, u, lms, mode in (("one marker, rb, stopped", (0, 0), [3], "rb"), ("one marker, rb, moving", (0.15, 0), [3], "rb"),
                           ("one marker, rb+psi, stopped", (0, 0), [3], "pose"), ("two markers, rb, stopped", (0, 0), [3, 8], "rb"),
                           ("no marker", (0.15, 0), [], "rb")):
    if not lms:
        out.append(f"  {name:28s}: rank 0/3 (dead reckoning, P grows)")
        continue
    r, c = obs(x, u, lms, mode)
    out.append(f"  {name:28s}: rank {r}/3, sigma_min/sigma_max = {c:.1e}")
out.append("  range+bearing from ONE marker gives 2 numbers for a 3-state pose: unobservable when stopped, weakly observable when moving.")
out.append("  The marker-heading measurement (psi) makes heading directly observable, but PnP heading is poor at range (see calibrate_vision.py).")
txt = "\n".join(out); print(txt)
os.makedirs("results", exist_ok=True); open("results/analysis.txt", "w").write(txt)
