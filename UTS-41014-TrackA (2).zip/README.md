# UTS 41014 — Track A Autonomous Navigation

## Project overview

This project demonstrates a simplified TurtleBot3-style
differential-drive robot navigating autonomously in MuJoCo.

The navigation system combines:
- A* path planning
- LQR path-following control
- Extended Kalman Filter (EKF) state estimation
- Wheel encoder odometry
- Geometric LiDAR obstacle sensing
- Simulated camera marker measurements
- A separate MuJoCo-rendered ArUco detection demonstration

## Simulation results

| Metric | Result |
|---|---|
| Navigation completed | Yes |
| Navigation time | 45.4 s |
| Docking position error | 0.027 m |
| Docking heading error | 2.48 degrees |
| EKF position RMSE | 0.0177 m |
| Simulated camera detections | 572 |

## Project structure

- `tb3nav/` — navigation and estimation algorithms
- `TrackA_Complete_Simulation.ipynb` — Colab demonstration
- `trackA_stable_robot.xml` — MuJoCo robot model
- `aruco_marker.png` — ArUco marker texture
- `results/` — simulation results and figures

## Running the project

Open `TrackA_Complete_Simulation.ipynb` in Google Colab.

Install the dependencies used in the notebook and execute
the cells in order.

## Limitations

The robot is constrained to planar movement.
Wheel motion is simulated through MuJoCo actuators.

The navigation system currently uses geometric LiDAR
and camera observations. ArUco detection from a rendered
MuJoCo camera has been demonstrated separately, but is
not yet integrated into the navigation EKF.

## Assessment

UTS 41014 — Sensors and Control for Mechatronic Systems
Track A — Integrated Project
